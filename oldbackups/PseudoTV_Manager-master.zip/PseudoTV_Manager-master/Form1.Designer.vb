﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.txtShowNetwork = New System.Windows.Forms.ComboBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ListTVGenres = New System.Windows.Forms.ListBox()
        Me.TVShowPictureBox = New System.Windows.Forms.PictureBox()
        Me.TVShowLabel = New System.Windows.Forms.Label()
        Me.SaveTVShow = New System.Windows.Forms.Button()
        Me.txtShowLocation = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtShowName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TVShowList = New System.Windows.Forms.ListView()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.MovieIDLabel = New System.Windows.Forms.Label()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.txtMovieNetwork = New System.Windows.Forms.ComboBox()
        Me.MovieLocation = New System.Windows.Forms.TextBox()
        Me.MovieLabel = New System.Windows.Forms.Label()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.MovieGenresList = New System.Windows.Forms.ListBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.MovieList = New System.Windows.Forms.ListView()
        Me.MoviePicture = New System.Windows.Forms.PictureBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.MovieNetworkListSubList = New System.Windows.Forms.ListBox()
        Me.MovieNetworkList = New System.Windows.Forms.ListView()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NetworkListSubList = New System.Windows.Forms.ListBox()
        Me.NetworkList = New System.Windows.Forms.ListView()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GenresListSubListMovies = New System.Windows.Forms.ListBox()
        Me.GenresListSubList = New System.Windows.Forms.ListBox()
        Me.GenresList = New System.Windows.Forms.ListView()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.TVGuideSubMenu = New System.Windows.Forms.ListView()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DontShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TVGuideShowName = New System.Windows.Forms.Label()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.NotShows = New System.Windows.Forms.ListBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SchedulingList = New System.Windows.Forms.ListView()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.InterleavedList = New System.Windows.Forms.ListView()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ResetDays = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ChannelName = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ChkPlayInOrder = New System.Windows.Forms.CheckBox()
        Me.ChkPause = New System.Windows.Forms.CheckBox()
        Me.ChkWatched = New System.Windows.Forms.CheckBox()
        Me.ChkUnwatched = New System.Windows.Forms.CheckBox()
        Me.ChkIceLibrary = New System.Windows.Forms.CheckBox()
        Me.ChkResume = New System.Windows.Forms.CheckBox()
        Me.ChkRealTime = New System.Windows.Forms.CheckBox()
        Me.ChkRandom = New System.Windows.Forms.CheckBox()
        Me.chkDontPlayChannel = New System.Windows.Forms.CheckBox()
        Me.ChkLogo = New System.Windows.Forms.CheckBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Option2 = New System.Windows.Forms.ComboBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.PlayListLocation = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PlayListType = New System.Windows.Forms.ComboBox()
        Me.TVGuideList = New System.Windows.Forms.ListView()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.Status = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AaaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.TVShowPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        CType(Me.MoviePicture, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(0, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1051, 774)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gray
        Me.TabPage1.Controls.Add(Me.Button19)
        Me.TabPage1.Controls.Add(Me.Button6)
        Me.TabPage1.Controls.Add(Me.txtShowNetwork)
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.ListTVGenres)
        Me.TabPage1.Controls.Add(Me.TVShowPictureBox)
        Me.TabPage1.Controls.Add(Me.TVShowLabel)
        Me.TabPage1.Controls.Add(Me.SaveTVShow)
        Me.TabPage1.Controls.Add(Me.txtShowLocation)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.TxtShowName)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.TVShowList)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1043, 748)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "TV Shows"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(651, 45)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(31, 29)
        Me.Button6.TabIndex = 17
        Me.Button6.Text = "..."
        Me.Button6.UseVisualStyleBackColor = True
        '
        'txtShowNetwork
        '
        Me.txtShowNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtShowNetwork.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShowNetwork.FormattingEnabled = True
        Me.txtShowNetwork.Location = New System.Drawing.Point(382, 45)
        Me.txtShowNetwork.Name = "txtShowNetwork"
        Me.txtShowNetwork.Size = New System.Drawing.Size(263, 28)
        Me.txtShowNetwork.TabIndex = 16
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(449, 198)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(37, 21)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "Del"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(406, 198)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(37, 21)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "Add"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'ListTVGenres
        '
        Me.ListTVGenres.FormattingEnabled = True
        Me.ListTVGenres.Location = New System.Drawing.Point(223, 222)
        Me.ListTVGenres.Name = "ListTVGenres"
        Me.ListTVGenres.Size = New System.Drawing.Size(265, 199)
        Me.ListTVGenres.TabIndex = 13
        '
        'TVShowPictureBox
        '
        Me.TVShowPictureBox.Location = New System.Drawing.Point(576, 198)
        Me.TVShowPictureBox.Name = "TVShowPictureBox"
        Me.TVShowPictureBox.Size = New System.Drawing.Size(302, 414)
        Me.TVShowPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.TVShowPictureBox.TabIndex = 12
        Me.TVShowPictureBox.TabStop = False
        '
        'TVShowLabel
        '
        Me.TVShowLabel.AutoSize = True
        Me.TVShowLabel.Location = New System.Drawing.Point(684, 22)
        Me.TVShowLabel.Name = "TVShowLabel"
        Me.TVShowLabel.Size = New System.Drawing.Size(39, 13)
        Me.TVShowLabel.TabIndex = 11
        Me.TVShowLabel.Text = "Label5"
        Me.TVShowLabel.Visible = False
        '
        'SaveTVShow
        '
        Me.SaveTVShow.Location = New System.Drawing.Point(565, 115)
        Me.SaveTVShow.Name = "SaveTVShow"
        Me.SaveTVShow.Size = New System.Drawing.Size(80, 30)
        Me.SaveTVShow.TabIndex = 10
        Me.SaveTVShow.Text = "Save"
        Me.SaveTVShow.UseVisualStyleBackColor = True
        '
        'txtShowLocation
        '
        Me.txtShowLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShowLocation.Location = New System.Drawing.Point(382, 83)
        Me.txtShowLocation.Name = "txtShowLocation"
        Me.txtShowLocation.Size = New System.Drawing.Size(378, 22)
        Me.txtShowLocation.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(223, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 29)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Location"
        '
        'TxtShowName
        '
        Me.TxtShowName.Enabled = False
        Me.TxtShowName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtShowName.Location = New System.Drawing.Point(382, 9)
        Me.TxtShowName.Name = "TxtShowName"
        Me.TxtShowName.Size = New System.Drawing.Size(261, 26)
        Me.TxtShowName.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(223, 45)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(103, 29)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Network"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(224, 190)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 29)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Genres"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(223, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(145, 29)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Show Name"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(3, 625)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(53, 20)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Refresh"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TVShowList
        '
        Me.TVShowList.FullRowSelect = True
        Me.TVShowList.HideSelection = False
        Me.TVShowList.Location = New System.Drawing.Point(3, 3)
        Me.TVShowList.MultiSelect = False
        Me.TVShowList.Name = "TVShowList"
        Me.TVShowList.Size = New System.Drawing.Size(214, 616)
        Me.TVShowList.TabIndex = 0
        Me.TVShowList.UseCompatibleStateImageBehavior = False
        Me.TVShowList.View = System.Windows.Forms.View.Details
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.Gray
        Me.TabPage5.Controls.Add(Me.Button18)
        Me.TabPage5.Controls.Add(Me.MovieIDLabel)
        Me.TabPage5.Controls.Add(Me.Button17)
        Me.TabPage5.Controls.Add(Me.txtMovieNetwork)
        Me.TabPage5.Controls.Add(Me.MovieLocation)
        Me.TabPage5.Controls.Add(Me.MovieLabel)
        Me.TabPage5.Controls.Add(Me.Button15)
        Me.TabPage5.Controls.Add(Me.Button16)
        Me.TabPage5.Controls.Add(Me.MovieGenresList)
        Me.TabPage5.Controls.Add(Me.Label13)
        Me.TabPage5.Controls.Add(Me.MovieList)
        Me.TabPage5.Controls.Add(Me.MoviePicture)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1043, 748)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Movies"
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(501, 48)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(31, 29)
        Me.Button18.TabIndex = 25
        Me.Button18.Text = "..."
        Me.Button18.UseVisualStyleBackColor = True
        '
        'MovieIDLabel
        '
        Me.MovieIDLabel.AutoSize = True
        Me.MovieIDLabel.Location = New System.Drawing.Point(553, 12)
        Me.MovieIDLabel.Name = "MovieIDLabel"
        Me.MovieIDLabel.Size = New System.Drawing.Size(45, 13)
        Me.MovieIDLabel.TabIndex = 24
        Me.MovieIDLabel.Text = "Label16"
        Me.MovieIDLabel.Visible = False
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(234, 386)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(79, 31)
        Me.Button17.TabIndex = 23
        Me.Button17.Text = "Save"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'txtMovieNetwork
        '
        Me.txtMovieNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtMovieNetwork.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMovieNetwork.FormattingEnabled = True
        Me.txtMovieNetwork.Location = New System.Drawing.Point(232, 48)
        Me.txtMovieNetwork.Name = "txtMovieNetwork"
        Me.txtMovieNetwork.Size = New System.Drawing.Size(263, 28)
        Me.txtMovieNetwork.TabIndex = 22
        '
        'MovieLocation
        '
        Me.MovieLocation.Location = New System.Drawing.Point(232, 96)
        Me.MovieLocation.Name = "MovieLocation"
        Me.MovieLocation.Size = New System.Drawing.Size(265, 20)
        Me.MovieLocation.TabIndex = 21
        '
        'MovieLabel
        '
        Me.MovieLabel.AutoSize = True
        Me.MovieLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MovieLabel.Location = New System.Drawing.Point(237, 12)
        Me.MovieLabel.Name = "MovieLabel"
        Me.MovieLabel.Size = New System.Drawing.Size(0, 25)
        Me.MovieLabel.TabIndex = 20
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(460, 147)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(37, 21)
        Me.Button15.TabIndex = 19
        Me.Button15.Text = "Del"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(417, 147)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(37, 21)
        Me.Button16.TabIndex = 18
        Me.Button16.Text = "Add"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'MovieGenresList
        '
        Me.MovieGenresList.FormattingEnabled = True
        Me.MovieGenresList.Location = New System.Drawing.Point(234, 171)
        Me.MovieGenresList.Name = "MovieGenresList"
        Me.MovieGenresList.Size = New System.Drawing.Size(265, 199)
        Me.MovieGenresList.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(235, 139)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(92, 29)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Genres"
        '
        'MovieList
        '
        Me.MovieList.FullRowSelect = True
        Me.MovieList.HideSelection = False
        Me.MovieList.Location = New System.Drawing.Point(3, 3)
        Me.MovieList.MultiSelect = False
        Me.MovieList.Name = "MovieList"
        Me.MovieList.Size = New System.Drawing.Size(214, 616)
        Me.MovieList.TabIndex = 14
        Me.MovieList.UseCompatibleStateImageBehavior = False
        Me.MovieList.View = System.Windows.Forms.View.Details
        '
        'MoviePicture
        '
        Me.MoviePicture.Location = New System.Drawing.Point(556, 68)
        Me.MoviePicture.Name = "MoviePicture"
        Me.MoviePicture.Size = New System.Drawing.Size(302, 414)
        Me.MoviePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.MoviePicture.TabIndex = 13
        Me.MoviePicture.TabStop = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Gray
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.MovieNetworkListSubList)
        Me.TabPage2.Controls.Add(Me.MovieNetworkList)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.NetworkListSubList)
        Me.TabPage2.Controls.Add(Me.NetworkList)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1043, 748)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Networks / Studios"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.Silver
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(464, 6)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(261, 20)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Movie Studios"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'MovieNetworkListSubList
        '
        Me.MovieNetworkListSubList.FormattingEnabled = True
        Me.MovieNetworkListSubList.Location = New System.Drawing.Point(731, 29)
        Me.MovieNetworkListSubList.Name = "MovieNetworkListSubList"
        Me.MovieNetworkListSubList.Size = New System.Drawing.Size(198, 316)
        Me.MovieNetworkListSubList.TabIndex = 5
        '
        'MovieNetworkList
        '
        Me.MovieNetworkList.FullRowSelect = True
        Me.MovieNetworkList.HideSelection = False
        Me.MovieNetworkList.Location = New System.Drawing.Point(464, 29)
        Me.MovieNetworkList.Name = "MovieNetworkList"
        Me.MovieNetworkList.Size = New System.Drawing.Size(261, 595)
        Me.MovieNetworkList.TabIndex = 4
        Me.MovieNetworkList.UseCompatibleStateImageBehavior = False
        Me.MovieNetworkList.View = System.Windows.Forms.View.Details
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Silver
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(3, 6)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(251, 20)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "TV Networks"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NetworkListSubList
        '
        Me.NetworkListSubList.FormattingEnabled = True
        Me.NetworkListSubList.Location = New System.Drawing.Point(260, 29)
        Me.NetworkListSubList.Name = "NetworkListSubList"
        Me.NetworkListSubList.Size = New System.Drawing.Size(198, 316)
        Me.NetworkListSubList.TabIndex = 2
        '
        'NetworkList
        '
        Me.NetworkList.FullRowSelect = True
        Me.NetworkList.HideSelection = False
        Me.NetworkList.Location = New System.Drawing.Point(3, 29)
        Me.NetworkList.Name = "NetworkList"
        Me.NetworkList.Size = New System.Drawing.Size(251, 595)
        Me.NetworkList.TabIndex = 1
        Me.NetworkList.UseCompatibleStateImageBehavior = False
        Me.NetworkList.View = System.Windows.Forms.View.Details
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Gray
        Me.TabPage3.Controls.Add(Me.Label17)
        Me.TabPage3.Controls.Add(Me.Label16)
        Me.TabPage3.Controls.Add(Me.GenresListSubListMovies)
        Me.TabPage3.Controls.Add(Me.GenresListSubList)
        Me.TabPage3.Controls.Add(Me.GenresList)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1043, 748)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Genres"
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Silver
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(675, 13)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(192, 20)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "Movies"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Silver
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(333, 13)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(192, 20)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "TV Shows"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GenresListSubListMovies
        '
        Me.GenresListSubListMovies.FormattingEnabled = True
        Me.GenresListSubListMovies.Location = New System.Drawing.Point(675, 36)
        Me.GenresListSubListMovies.Name = "GenresListSubListMovies"
        Me.GenresListSubListMovies.Size = New System.Drawing.Size(192, 420)
        Me.GenresListSubListMovies.TabIndex = 4
        '
        'GenresListSubList
        '
        Me.GenresListSubList.FormattingEnabled = True
        Me.GenresListSubList.Location = New System.Drawing.Point(333, 36)
        Me.GenresListSubList.Name = "GenresListSubList"
        Me.GenresListSubList.Size = New System.Drawing.Size(192, 420)
        Me.GenresListSubList.TabIndex = 3
        '
        'GenresList
        '
        Me.GenresList.FullRowSelect = True
        Me.GenresList.HideSelection = False
        Me.GenresList.Location = New System.Drawing.Point(3, 3)
        Me.GenresList.Name = "GenresList"
        Me.GenresList.Size = New System.Drawing.Size(305, 627)
        Me.GenresList.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.GenresList.TabIndex = 2
        Me.GenresList.UseCompatibleStateImageBehavior = False
        Me.GenresList.View = System.Windows.Forms.View.Details
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.Gray
        Me.TabPage4.Controls.Add(Me.TVGuideSubMenu)
        Me.TabPage4.Controls.Add(Me.TVGuideShowName)
        Me.TabPage4.Controls.Add(Me.Button13)
        Me.TabPage4.Controls.Add(Me.Button14)
        Me.TabPage4.Controls.Add(Me.Button11)
        Me.TabPage4.Controls.Add(Me.Button12)
        Me.TabPage4.Controls.Add(Me.Button9)
        Me.TabPage4.Controls.Add(Me.Button10)
        Me.TabPage4.Controls.Add(Me.Button8)
        Me.TabPage4.Controls.Add(Me.Button7)
        Me.TabPage4.Controls.Add(Me.Button2)
        Me.TabPage4.Controls.Add(Me.NotShows)
        Me.TabPage4.Controls.Add(Me.Label12)
        Me.TabPage4.Controls.Add(Me.SchedulingList)
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.InterleavedList)
        Me.TabPage4.Controls.Add(Me.Label7)
        Me.TabPage4.Controls.Add(Me.ResetDays)
        Me.TabPage4.Controls.Add(Me.Label10)
        Me.TabPage4.Controls.Add(Me.ChannelName)
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.ChkPlayInOrder)
        Me.TabPage4.Controls.Add(Me.ChkPause)
        Me.TabPage4.Controls.Add(Me.ChkWatched)
        Me.TabPage4.Controls.Add(Me.ChkUnwatched)
        Me.TabPage4.Controls.Add(Me.ChkIceLibrary)
        Me.TabPage4.Controls.Add(Me.ChkResume)
        Me.TabPage4.Controls.Add(Me.ChkRealTime)
        Me.TabPage4.Controls.Add(Me.ChkRandom)
        Me.TabPage4.Controls.Add(Me.chkDontPlayChannel)
        Me.TabPage4.Controls.Add(Me.ChkLogo)
        Me.TabPage4.Controls.Add(Me.Label8)
        Me.TabPage4.Controls.Add(Me.Option2)
        Me.TabPage4.Controls.Add(Me.Button5)
        Me.TabPage4.Controls.Add(Me.PlayListLocation)
        Me.TabPage4.Controls.Add(Me.Label6)
        Me.TabPage4.Controls.Add(Me.Label5)
        Me.TabPage4.Controls.Add(Me.PlayListType)
        Me.TabPage4.Controls.Add(Me.TVGuideList)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1043, 748)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TV Guide"
        '
        'TVGuideSubMenu
        '
        Me.TVGuideSubMenu.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TVGuideSubMenu.Location = New System.Drawing.Point(149, 214)
        Me.TVGuideSubMenu.Name = "TVGuideSubMenu"
        Me.TVGuideSubMenu.Size = New System.Drawing.Size(180, 303)
        Me.TVGuideSubMenu.TabIndex = 42
        Me.TVGuideSubMenu.UseCompatibleStateImageBehavior = False
        Me.TVGuideSubMenu.View = System.Windows.Forms.View.Details
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DontShowToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(136, 26)
        '
        'DontShowToolStripMenuItem
        '
        Me.DontShowToolStripMenuItem.Name = "DontShowToolStripMenuItem"
        Me.DontShowToolStripMenuItem.Size = New System.Drawing.Size(135, 22)
        Me.DontShowToolStripMenuItem.Text = "Don't Show"
        '
        'TVGuideShowName
        '
        Me.TVGuideShowName.AutoSize = True
        Me.TVGuideShowName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TVGuideShowName.Location = New System.Drawing.Point(156, 13)
        Me.TVGuideShowName.Name = "TVGuideShowName"
        Me.TVGuideShowName.Size = New System.Drawing.Size(0, 24)
        Me.TVGuideShowName.TabIndex = 41
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(46, 619)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(37, 23)
        Me.Button13.TabIndex = 40
        Me.Button13.Text = "Del"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(3, 619)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(37, 23)
        Me.Button14.TabIndex = 39
        Me.Button14.Text = "Add"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(774, 590)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(37, 23)
        Me.Button11.TabIndex = 38
        Me.Button11.Text = "Del"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(731, 590)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(37, 23)
        Me.Button12.TabIndex = 37
        Me.Button12.Text = "Add"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(572, 590)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(37, 23)
        Me.Button9.TabIndex = 36
        Me.Button9.Text = "Del"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(529, 590)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(37, 23)
        Me.Button10.TabIndex = 35
        Me.Button10.Text = "Add"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(381, 590)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(37, 23)
        Me.Button8.TabIndex = 34
        Me.Button8.Text = "Del"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(338, 590)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(37, 23)
        Me.Button7.TabIndex = 33
        Me.Button7.Text = "Add"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(177, 533)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 33)
        Me.Button2.TabIndex = 32
        Me.Button2.Text = "Save"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'NotShows
        '
        Me.NotShows.FormattingEnabled = True
        Me.NotShows.Location = New System.Drawing.Point(731, 320)
        Me.NotShows.Name = "NotShows"
        Me.NotShows.Size = New System.Drawing.Size(161, 264)
        Me.NotShows.TabIndex = 31
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(728, 304)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(135, 13)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "Don't Include these shows:"
        '
        'SchedulingList
        '
        Me.SchedulingList.FullRowSelect = True
        Me.SchedulingList.Location = New System.Drawing.Point(529, 320)
        Me.SchedulingList.Name = "SchedulingList"
        Me.SchedulingList.Size = New System.Drawing.Size(194, 264)
        Me.SchedulingList.TabIndex = 29
        Me.SchedulingList.UseCompatibleStateImageBehavior = False
        Me.SchedulingList.View = System.Windows.Forms.View.Details
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(553, 304)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(102, 13)
        Me.Label11.TabIndex = 28
        Me.Label11.Text = "Channel Scheduling"
        '
        'InterleavedList
        '
        Me.InterleavedList.FullRowSelect = True
        Me.InterleavedList.Location = New System.Drawing.Point(338, 319)
        Me.InterleavedList.Name = "InterleavedList"
        Me.InterleavedList.Size = New System.Drawing.Size(188, 265)
        Me.InterleavedList.TabIndex = 27
        Me.InterleavedList.UseCompatibleStateImageBehavior = False
        Me.InterleavedList.View = System.Windows.Forms.View.Details
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(335, 307)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(107, 13)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Interleaved Channels"
        '
        'ResetDays
        '
        Me.ResetDays.Location = New System.Drawing.Point(446, 235)
        Me.ResetDays.Name = "ResetDays"
        Me.ResetDays.Size = New System.Drawing.Size(42, 20)
        Me.ResetDays.TabIndex = 25
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(337, 238)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(105, 13)
        Me.Label10.TabIndex = 24
        Me.Label10.Text = "Reset Every X Days:"
        '
        'ChannelName
        '
        Me.ChannelName.Location = New System.Drawing.Point(244, 65)
        Me.ChannelName.Name = "ChannelName"
        Me.ChannelName.Size = New System.Drawing.Size(198, 20)
        Me.ChannelName.TabIndex = 23
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(155, 60)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 24)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Name"
        '
        'ChkPlayInOrder
        '
        Me.ChkPlayInOrder.AutoSize = True
        Me.ChkPlayInOrder.Location = New System.Drawing.Point(606, 214)
        Me.ChkPlayInOrder.Name = "ChkPlayInOrder"
        Me.ChkPlayInOrder.Size = New System.Drawing.Size(117, 17)
        Me.ChkPlayInOrder.TabIndex = 21
        Me.ChkPlayInOrder.Text = "Play shows in order"
        Me.ChkPlayInOrder.UseVisualStyleBackColor = True
        '
        'ChkPause
        '
        Me.ChkPause.AutoSize = True
        Me.ChkPause.Location = New System.Drawing.Point(606, 237)
        Me.ChkPause.Name = "ChkPause"
        Me.ChkPause.Size = New System.Drawing.Size(149, 17)
        Me.ChkPause.TabIndex = 20
        Me.ChkPause.Text = "Pause when not watching"
        Me.ChkPause.UseVisualStyleBackColor = True
        '
        'ChkWatched
        '
        Me.ChkWatched.AutoSize = True
        Me.ChkWatched.Location = New System.Drawing.Point(730, 142)
        Me.ChkWatched.Name = "ChkWatched"
        Me.ChkWatched.Size = New System.Drawing.Size(113, 17)
        Me.ChkWatched.TabIndex = 19
        Me.ChkWatched.Text = "Only play watched"
        Me.ChkWatched.UseVisualStyleBackColor = True
        '
        'ChkUnwatched
        '
        Me.ChkUnwatched.AutoSize = True
        Me.ChkUnwatched.Location = New System.Drawing.Point(606, 142)
        Me.ChkUnwatched.Name = "ChkUnwatched"
        Me.ChkUnwatched.Size = New System.Drawing.Size(125, 17)
        Me.ChkUnwatched.TabIndex = 18
        Me.ChkUnwatched.Text = "Only play unwatched"
        Me.ChkUnwatched.UseVisualStyleBackColor = True
        '
        'ChkIceLibrary
        '
        Me.ChkIceLibrary.AutoSize = True
        Me.ChkIceLibrary.Location = New System.Drawing.Point(606, 191)
        Me.ChkIceLibrary.Name = "ChkIceLibrary"
        Me.ChkIceLibrary.Size = New System.Drawing.Size(119, 17)
        Me.ChkIceLibrary.TabIndex = 17
        Me.ChkIceLibrary.Text = "IceLibrary Streams?"
        Me.ChkIceLibrary.UseVisualStyleBackColor = True
        '
        'ChkResume
        '
        Me.ChkResume.AutoSize = True
        Me.ChkResume.Location = New System.Drawing.Point(606, 91)
        Me.ChkResume.Name = "ChkResume"
        Me.ChkResume.Size = New System.Drawing.Size(119, 17)
        Me.ChkResume.TabIndex = 16
        Me.ChkResume.Text = "Force resume mode"
        Me.ChkResume.UseVisualStyleBackColor = True
        '
        'ChkRealTime
        '
        Me.ChkRealTime.AutoSize = True
        Me.ChkRealTime.Location = New System.Drawing.Point(731, 68)
        Me.ChkRealTime.Name = "ChkRealTime"
        Me.ChkRealTime.Size = New System.Drawing.Size(124, 17)
        Me.ChkRealTime.TabIndex = 15
        Me.ChkRealTime.Text = "Force real-time mode"
        Me.ChkRealTime.UseVisualStyleBackColor = True
        '
        'ChkRandom
        '
        Me.ChkRandom.AutoSize = True
        Me.ChkRandom.Location = New System.Drawing.Point(606, 68)
        Me.ChkRandom.Name = "ChkRandom"
        Me.ChkRandom.Size = New System.Drawing.Size(120, 17)
        Me.ChkRandom.TabIndex = 14
        Me.ChkRandom.Text = "Force random mode"
        Me.ChkRandom.UseVisualStyleBackColor = True
        '
        'chkDontPlayChannel
        '
        Me.chkDontPlayChannel.AutoSize = True
        Me.chkDontPlayChannel.Location = New System.Drawing.Point(730, 22)
        Me.chkDontPlayChannel.Name = "chkDontPlayChannel"
        Me.chkDontPlayChannel.Size = New System.Drawing.Size(133, 17)
        Me.chkDontPlayChannel.TabIndex = 13
        Me.chkDontPlayChannel.Text = "Don't play this channel"
        Me.chkDontPlayChannel.UseVisualStyleBackColor = True
        '
        'ChkLogo
        '
        Me.ChkLogo.AutoSize = True
        Me.ChkLogo.Location = New System.Drawing.Point(606, 22)
        Me.ChkLogo.Name = "ChkLogo"
        Me.ChkLogo.Size = New System.Drawing.Size(83, 17)
        Me.ChkLogo.TabIndex = 12
        Me.ChkLogo.Text = "Display logo"
        Me.ChkLogo.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(143, 41)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(0, 24)
        Me.Label8.TabIndex = 10
        '
        'Option2
        '
        Me.Option2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Option2.FormattingEnabled = True
        Me.Option2.Location = New System.Drawing.Point(244, 125)
        Me.Option2.Name = "Option2"
        Me.Option2.Size = New System.Drawing.Size(198, 21)
        Me.Option2.TabIndex = 9
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(447, 171)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(32, 20)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "..."
        Me.Button5.UseVisualStyleBackColor = True
        Me.Button5.Visible = False
        '
        'PlayListLocation
        '
        Me.PlayListLocation.Location = New System.Drawing.Point(244, 167)
        Me.PlayListLocation.Name = "PlayListLocation"
        Me.PlayListLocation.Size = New System.Drawing.Size(198, 20)
        Me.PlayListLocation.TabIndex = 5
        Me.PlayListLocation.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(154, 167)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 24)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Location:"
        Me.Label6.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(154, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 24)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Type:"
        '
        'PlayListType
        '
        Me.PlayListType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.PlayListType.FormattingEnabled = True
        Me.PlayListType.Items.AddRange(New Object() {"Playlist", "TV Network", "Movie Studio", "TV Genre", "Movie Genre", "Mixed Genre (Tv & Movie)", "TV Show", "Directory"})
        Me.PlayListType.Location = New System.Drawing.Point(244, 98)
        Me.PlayListType.Name = "PlayListType"
        Me.PlayListType.Size = New System.Drawing.Size(198, 21)
        Me.PlayListType.TabIndex = 2
        '
        'TVGuideList
        '
        Me.TVGuideList.FullRowSelect = True
        Me.TVGuideList.HideSelection = False
        Me.TVGuideList.Location = New System.Drawing.Point(3, 3)
        Me.TVGuideList.Name = "TVGuideList"
        Me.TVGuideList.Size = New System.Drawing.Size(140, 610)
        Me.TVGuideList.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.TVGuideList.TabIndex = 1
        Me.TVGuideList.UseCompatibleStateImageBehavior = False
        Me.TVGuideList.View = System.Windows.Forms.View.Details
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 697)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(943, 22)
        Me.StatusStrip1.TabIndex = 1
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'Status
        '
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(0, 17)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(943, 24)
        Me.MenuStrip1.TabIndex = 2
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AaaToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "&File"
        '
        'AaaToolStripMenuItem
        '
        Me.AaaToolStripMenuItem.Name = "AaaToolStripMenuItem"
        Me.AaaToolStripMenuItem.Size = New System.Drawing.Size(116, 22)
        Me.AaaToolStripMenuItem.Text = "Settings"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(384, 127)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(58, 27)
        Me.Button19.TabIndex = 18
        Me.Button19.Text = "Button19"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(943, 719)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "PseudoTV Manager"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.TVShowPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.MoviePicture, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents Status As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AaaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TVShowList As System.Windows.Forms.ListView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtShowName As System.Windows.Forms.TextBox
    Friend WithEvents txtShowLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SaveTVShow As System.Windows.Forms.Button
    Friend WithEvents TVShowLabel As System.Windows.Forms.Label
    Friend WithEvents TVShowPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents NetworkList As System.Windows.Forms.ListView
    Friend WithEvents NetworkListSubList As System.Windows.Forms.ListBox
    Friend WithEvents ListTVGenres As System.Windows.Forms.ListBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GenresList As System.Windows.Forms.ListView
    Friend WithEvents GenresListSubList As System.Windows.Forms.ListBox
    Friend WithEvents txtShowNetwork As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TVGuideList As System.Windows.Forms.ListView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PlayListType As System.Windows.Forms.ComboBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents PlayListLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Option2 As System.Windows.Forms.ComboBox
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents ChannelName As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ChkPlayInOrder As System.Windows.Forms.CheckBox
    Friend WithEvents ChkPause As System.Windows.Forms.CheckBox
    Friend WithEvents ChkWatched As System.Windows.Forms.CheckBox
    Friend WithEvents ChkUnwatched As System.Windows.Forms.CheckBox
    Friend WithEvents ChkIceLibrary As System.Windows.Forms.CheckBox
    Friend WithEvents ChkResume As System.Windows.Forms.CheckBox
    Friend WithEvents ChkRealTime As System.Windows.Forms.CheckBox
    Friend WithEvents ChkRandom As System.Windows.Forms.CheckBox
    Friend WithEvents chkDontPlayChannel As System.Windows.Forms.CheckBox
    Friend WithEvents ChkLogo As System.Windows.Forms.CheckBox
    Friend WithEvents ResetDays As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents InterleavedList As System.Windows.Forms.ListView
    Friend WithEvents NotShows As System.Windows.Forms.ListBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents SchedulingList As System.Windows.Forms.ListView
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TVGuideShowName As System.Windows.Forms.Label
    Friend WithEvents TVGuideSubMenu As System.Windows.Forms.ListView
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DontShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents MovieLabel As System.Windows.Forms.Label
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents MovieGenresList As System.Windows.Forms.ListBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents MovieList As System.Windows.Forms.ListView
    Friend WithEvents MoviePicture As System.Windows.Forms.PictureBox
    Friend WithEvents MovieLocation As System.Windows.Forms.TextBox
    Friend WithEvents txtMovieNetwork As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents MovieNetworkListSubList As System.Windows.Forms.ListBox
    Friend WithEvents MovieNetworkList As System.Windows.Forms.ListView
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents MovieIDLabel As System.Windows.Forms.Label
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents GenresListSubListMovies As System.Windows.Forms.ListBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Button19 As System.Windows.Forms.Button

End Class
