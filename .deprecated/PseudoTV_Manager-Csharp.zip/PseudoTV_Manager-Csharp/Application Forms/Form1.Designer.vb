﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form
    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
		Me.TabControl1 = New System.Windows.Forms.TabControl()
		Me.TabPage1 = New System.Windows.Forms.TabPage()
		Me.Button20 = New System.Windows.Forms.Button()
		Me.AddPoster = New System.Windows.Forms.Button()
		Me.AddBanner = New System.Windows.Forms.Button()
		Me.TVPosterSelect = New System.Windows.Forms.Button()
		Me.TVBannerSelect = New System.Windows.Forms.Button()
		Me.TVBannerPictureBox = New System.Windows.Forms.PictureBox()
		Me.ListTVBanners = New System.Windows.Forms.ListBox()
		Me.Label20 = New System.Windows.Forms.Label()
		Me.Label18 = New System.Windows.Forms.Label()
		Me.ListTVPosters = New System.Windows.Forms.ListBox()
		Me.Button19 = New System.Windows.Forms.Button()
		Me.Button6 = New System.Windows.Forms.Button()
		Me.txtShowNetwork = New System.Windows.Forms.ComboBox()
		Me.Button4 = New System.Windows.Forms.Button()
		Me.Button3 = New System.Windows.Forms.Button()
		Me.ListTVGenres = New System.Windows.Forms.ListBox()
		Me.TVPosterPictureBox = New System.Windows.Forms.PictureBox()
		Me.TVShowLabel = New System.Windows.Forms.Label()
		Me.SaveTVShow = New System.Windows.Forms.Button()
		Me.txtShowLocation = New System.Windows.Forms.TextBox()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.TxtShowName = New System.Windows.Forms.TextBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.TVShowList = New System.Windows.Forms.ListView()
		Me.TabPage5 = New System.Windows.Forms.TabPage()
		Me.AddMoviePosterButton = New System.Windows.Forms.Button()
		Me.MoviePosterSelect = New System.Windows.Forms.Button()
		Me.Label19 = New System.Windows.Forms.Label()
		Me.ListMoviePosters = New System.Windows.Forms.ListBox()
		Me.Button18 = New System.Windows.Forms.Button()
		Me.MovieIDLabel = New System.Windows.Forms.Label()
		Me.Button17 = New System.Windows.Forms.Button()
		Me.txtMovieNetwork = New System.Windows.Forms.ComboBox()
		Me.MovieLocation = New System.Windows.Forms.TextBox()
		Me.MovieLabel = New System.Windows.Forms.Label()
		Me.Button15 = New System.Windows.Forms.Button()
		Me.Button16 = New System.Windows.Forms.Button()
		Me.MovieGenresList = New System.Windows.Forms.ListBox()
		Me.Label13 = New System.Windows.Forms.Label()
		Me.MovieList = New System.Windows.Forms.ListView()
		Me.MoviePicture = New System.Windows.Forms.PictureBox()
		Me.TabPage2 = New System.Windows.Forms.TabPage()
		Me.Label15 = New System.Windows.Forms.Label()
		Me.MovieNetworkListSubList = New System.Windows.Forms.ListBox()
		Me.MovieNetworkList = New System.Windows.Forms.ListView()
		Me.Label14 = New System.Windows.Forms.Label()
		Me.NetworkListSubList = New System.Windows.Forms.ListBox()
		Me.NetworkList = New System.Windows.Forms.ListView()
		Me.TabPage3 = New System.Windows.Forms.TabPage()
		Me.Label17 = New System.Windows.Forms.Label()
		Me.Label16 = New System.Windows.Forms.Label()
		Me.GenresListSubListMovies = New System.Windows.Forms.ListBox()
		Me.GenresListSubList = New System.Windows.Forms.ListBox()
		Me.GenresList = New System.Windows.Forms.ListView()
		Me.TabPage4 = New System.Windows.Forms.TabPage()
		Me.DelExcludeBtn = New System.Windows.Forms.Button()
		Me.SaveExcludeBtn = New System.Windows.Forms.Button()
		Me.AddExcludeBtn = New System.Windows.Forms.Button()
		Me.GDataDemoLink = New System.Windows.Forms.LinkLabel()
		Me.SortTypeBox = New System.Windows.Forms.ComboBox()
		Me.SortType = New System.Windows.Forms.Label()
		Me.MediaLimitBox = New System.Windows.Forms.ComboBox()
		Me.MediaLimit = New System.Windows.Forms.Label()
		Me.ShowDescBox = New System.Windows.Forms.TextBox()
		Me.ShowDesc = New System.Windows.Forms.Label()
		Me.ShowTitleBox = New System.Windows.Forms.TextBox()
		Me.ShowTitle = New System.Windows.Forms.Label()
		Me.YouTubeType = New System.Windows.Forms.ComboBox()
		Me.StrmUrlBox = New System.Windows.Forms.TextBox()
		Me.StrmUrl = New System.Windows.Forms.Label()
		Me.TVGuideSubMenu = New System.Windows.Forms.ListView()
		Me.TVGuideShowName = New System.Windows.Forms.Label()
		Me.Button13 = New System.Windows.Forms.Button()
		Me.Button14 = New System.Windows.Forms.Button()
		Me.Button11 = New System.Windows.Forms.Button()
		Me.Button12 = New System.Windows.Forms.Button()
		Me.Button9 = New System.Windows.Forms.Button()
		Me.Button10 = New System.Windows.Forms.Button()
		Me.Button8 = New System.Windows.Forms.Button()
		Me.Button7 = New System.Windows.Forms.Button()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.NotShows = New System.Windows.Forms.ListBox()
		Me.Label12 = New System.Windows.Forms.Label()
		Me.SchedulingList = New System.Windows.Forms.ListView()
		Me.Label11 = New System.Windows.Forms.Label()
		Me.InterleavedList = New System.Windows.Forms.ListView()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.ResetDays = New System.Windows.Forms.TextBox()
		Me.Label10 = New System.Windows.Forms.Label()
		Me.ChannelName = New System.Windows.Forms.TextBox()
		Me.Label9 = New System.Windows.Forms.Label()
		Me.ChkPlayInOrder = New System.Windows.Forms.CheckBox()
		Me.ChkPause = New System.Windows.Forms.CheckBox()
		Me.ChkWatched = New System.Windows.Forms.CheckBox()
		Me.ChkUnwatched = New System.Windows.Forms.CheckBox()
		Me.ChkIceLibrary = New System.Windows.Forms.CheckBox()
		Me.ChkExcludeBCT = New System.Windows.Forms.CheckBox()
		Me.ChkPopup = New System.Windows.Forms.CheckBox()
		Me.ChkResume = New System.Windows.Forms.CheckBox()
		Me.ChkRealTime = New System.Windows.Forms.CheckBox()
		Me.ChkRandom = New System.Windows.Forms.CheckBox()
		Me.chkDontPlayChannel = New System.Windows.Forms.CheckBox()
		Me.ChkLogo = New System.Windows.Forms.CheckBox()
		Me.Label8 = New System.Windows.Forms.Label()
		Me.Option2 = New System.Windows.Forms.ComboBox()
		Me.Button5 = New System.Windows.Forms.Button()
		Me.PlayListLocation = New System.Windows.Forms.TextBox()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.PlayListType = New System.Windows.Forms.ComboBox()
		Me.TVGuideList = New System.Windows.Forms.ListView()
		Me.PluginType = New System.Windows.Forms.ComboBox()
		Me.SubChannelType = New System.Windows.Forms.ComboBox()
		Me.TabPage6 = New System.Windows.Forms.TabPage()
		Me.Label24 = New System.Windows.Forms.Label()
		Me.Label23 = New System.Windows.Forms.Label()
		Me.LunaDonatePic = New System.Windows.Forms.PictureBox()
		Me.Label22 = New System.Windows.Forms.Label()
		Me.PeppyDonatePic = New System.Windows.Forms.PictureBox()
		Me.PeppyDonate = New System.Windows.Forms.Label()
		Me.HelpLink = New System.Windows.Forms.LinkLabel()
		Me.Label21 = New System.Windows.Forms.Label()
		Me.HelpList = New System.Windows.Forms.ComboBox()
		Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.AaaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
		Me.Status = New System.Windows.Forms.ToolStripStatusLabel()
		Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
		Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
		Me.TabControl1.SuspendLayout()
		Me.TabPage1.SuspendLayout()
		CType(Me.TVBannerPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.TVPosterPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.TabPage5.SuspendLayout()
		CType(Me.MoviePicture, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.TabPage2.SuspendLayout()
		Me.TabPage3.SuspendLayout()
		Me.TabPage4.SuspendLayout()
		Me.TabPage6.SuspendLayout()
		CType(Me.LunaDonatePic, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.PeppyDonatePic, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.MenuStrip1.SuspendLayout()
		Me.StatusStrip1.SuspendLayout()
		Me.SuspendLayout()
		'
		'TabControl1
		'
		Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.TabControl1.Controls.Add(Me.TabPage1)
		Me.TabControl1.Controls.Add(Me.TabPage5)
		Me.TabControl1.Controls.Add(Me.TabPage2)
		Me.TabControl1.Controls.Add(Me.TabPage3)
		Me.TabControl1.Controls.Add(Me.TabPage4)
		Me.TabControl1.Controls.Add(Me.TabPage6)
		Me.TabControl1.Location = New System.Drawing.Point(0, 27)
		Me.TabControl1.MaximumSize = New System.Drawing.Size(1000, 900)
		Me.TabControl1.MinimumSize = New System.Drawing.Size(1000, 688)
		Me.TabControl1.Name = "TabControl1"
		Me.TabControl1.SelectedIndex = 0
		Me.TabControl1.Size = New System.Drawing.Size(1000, 688)
		Me.TabControl1.TabIndex = 0
		'
		'TabPage1
		'
		Me.TabPage1.BackColor = System.Drawing.Color.Gray
		Me.TabPage1.Controls.Add(Me.Button20)
		Me.TabPage1.Controls.Add(Me.AddPoster)
		Me.TabPage1.Controls.Add(Me.AddBanner)
		Me.TabPage1.Controls.Add(Me.TVPosterSelect)
		Me.TabPage1.Controls.Add(Me.TVBannerSelect)
		Me.TabPage1.Controls.Add(Me.TVBannerPictureBox)
		Me.TabPage1.Controls.Add(Me.ListTVBanners)
		Me.TabPage1.Controls.Add(Me.Label20)
		Me.TabPage1.Controls.Add(Me.Label18)
		Me.TabPage1.Controls.Add(Me.ListTVPosters)
		Me.TabPage1.Controls.Add(Me.Button19)
		Me.TabPage1.Controls.Add(Me.Button6)
		Me.TabPage1.Controls.Add(Me.txtShowNetwork)
		Me.TabPage1.Controls.Add(Me.Button4)
		Me.TabPage1.Controls.Add(Me.Button3)
		Me.TabPage1.Controls.Add(Me.ListTVGenres)
		Me.TabPage1.Controls.Add(Me.TVPosterPictureBox)
		Me.TabPage1.Controls.Add(Me.TVShowLabel)
		Me.TabPage1.Controls.Add(Me.SaveTVShow)
		Me.TabPage1.Controls.Add(Me.txtShowLocation)
		Me.TabPage1.Controls.Add(Me.Label4)
		Me.TabPage1.Controls.Add(Me.TxtShowName)
		Me.TabPage1.Controls.Add(Me.Label3)
		Me.TabPage1.Controls.Add(Me.Label2)
		Me.TabPage1.Controls.Add(Me.Label1)
		Me.TabPage1.Controls.Add(Me.Button1)
		Me.TabPage1.Controls.Add(Me.TVShowList)
		Me.TabPage1.Location = New System.Drawing.Point(4, 22)
		Me.TabPage1.Name = "TabPage1"
		Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
		Me.TabPage1.Size = New System.Drawing.Size(992, 662)
		Me.TabPage1.TabIndex = 0
		Me.TabPage1.Text = "TV Shows"
		'
		'Button20
		'
		Me.Button20.Location = New System.Drawing.Point(387, 104)
		Me.Button20.Name = "Button20"
		Me.Button20.Size = New System.Drawing.Size(75, 23)
		Me.Button20.TabIndex = 28
		Me.Button20.Text = "Button20"
		Me.Button20.UseVisualStyleBackColor = True
		Me.Button20.Visible = False
		'
		'AddPoster
		'
		Me.AddPoster.Location = New System.Drawing.Point(547, 612)
		Me.AddPoster.Name = "AddPoster"
		Me.AddPoster.Size = New System.Drawing.Size(39, 21)
		Me.AddPoster.TabIndex = 27
		Me.AddPoster.Text = "Add"
		Me.AddPoster.UseVisualStyleBackColor = True
		'
		'AddBanner
		'
		Me.AddBanner.Location = New System.Drawing.Point(547, 422)
		Me.AddBanner.Name = "AddBanner"
		Me.AddBanner.Size = New System.Drawing.Size(39, 21)
		Me.AddBanner.TabIndex = 26
		Me.AddBanner.Text = "Add"
		Me.AddBanner.UseVisualStyleBackColor = True
		'
		'TVPosterSelect
		'
		Me.TVPosterSelect.Location = New System.Drawing.Point(235, 612)
		Me.TVPosterSelect.Name = "TVPosterSelect"
		Me.TVPosterSelect.Size = New System.Drawing.Size(98, 23)
		Me.TVPosterSelect.TabIndex = 25
		Me.TVPosterSelect.Text = "Save image"
		Me.TVPosterSelect.UseVisualStyleBackColor = True
		'
		'TVBannerSelect
		'
		Me.TVBannerSelect.Location = New System.Drawing.Point(235, 420)
		Me.TVBannerSelect.Name = "TVBannerSelect"
		Me.TVBannerSelect.Size = New System.Drawing.Size(98, 23)
		Me.TVBannerSelect.TabIndex = 24
		Me.TVBannerSelect.Text = "Save image"
		Me.TVBannerSelect.UseVisualStyleBackColor = True
		'
		'TVBannerPictureBox
		'
		Me.TVBannerPictureBox.InitialImage = CType(resources.GetObject("TVBannerPictureBox.InitialImage"), System.Drawing.Image)
		Me.TVBannerPictureBox.Location = New System.Drawing.Point(592, 104)
		Me.TVBannerPictureBox.Name = "TVBannerPictureBox"
		Me.TVBannerPictureBox.Size = New System.Drawing.Size(339, 50)
		Me.TVBannerPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.TVBannerPictureBox.TabIndex = 23
		Me.TVBannerPictureBox.TabStop = False
		'
		'ListTVBanners
		'
		Me.ListTVBanners.FormattingEnabled = True
		Me.ListTVBanners.Location = New System.Drawing.Point(235, 295)
		Me.ListTVBanners.Name = "ListTVBanners"
		Me.ListTVBanners.Size = New System.Drawing.Size(349, 121)
		Me.ListTVBanners.TabIndex = 22
		'
		'Label20
		'
		Me.Label20.AutoSize = True
		Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label20.Location = New System.Drawing.Point(232, 271)
		Me.Label20.Name = "Label20"
		Me.Label20.Size = New System.Drawing.Size(110, 24)
		Me.Label20.TabIndex = 21
		Me.Label20.Text = "TV Banners"
		'
		'Label18
		'
		Me.Label18.AutoSize = True
		Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label18.Location = New System.Drawing.Point(231, 448)
		Me.Label18.Name = "Label18"
		Me.Label18.Size = New System.Drawing.Size(102, 24)
		Me.Label18.TabIndex = 20
		Me.Label18.Text = "TV Posters"
		'
		'ListTVPosters
		'
		Me.ListTVPosters.FormattingEnabled = True
		Me.ListTVPosters.Location = New System.Drawing.Point(236, 472)
		Me.ListTVPosters.Name = "ListTVPosters"
		Me.ListTVPosters.Size = New System.Drawing.Size(351, 134)
		Me.ListTVPosters.TabIndex = 19
		'
		'Button19
		'
		Me.Button19.Enabled = False
		Me.Button19.Location = New System.Drawing.Point(365, 136)
		Me.Button19.Name = "Button19"
		Me.Button19.Size = New System.Drawing.Size(62, 21)
		Me.Button19.TabIndex = 18
		Me.Button19.Text = "Refresh"
		Me.Button19.UseVisualStyleBackColor = True
		Me.Button19.Visible = False
		'
		'Button6
		'
		Me.Button6.Location = New System.Drawing.Point(610, 73)
		Me.Button6.Name = "Button6"
		Me.Button6.Size = New System.Drawing.Size(29, 24)
		Me.Button6.TabIndex = 17
		Me.Button6.Text = "..."
		Me.Button6.UseVisualStyleBackColor = True
		'
		'txtShowNetwork
		'
		Me.txtShowNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.txtShowNetwork.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtShowNetwork.FormattingEnabled = True
		Me.txtShowNetwork.Location = New System.Drawing.Point(324, 39)
		Me.txtShowNetwork.Name = "txtShowNetwork"
		Me.txtShowNetwork.Size = New System.Drawing.Size(280, 28)
		Me.txtShowNetwork.TabIndex = 16
		'
		'Button4
		'
		Me.Button4.Location = New System.Drawing.Point(481, 136)
		Me.Button4.Name = "Button4"
		Me.Button4.Size = New System.Drawing.Size(39, 21)
		Me.Button4.TabIndex = 15
		Me.Button4.Text = "Del"
		Me.Button4.UseVisualStyleBackColor = True
		'
		'Button3
		'
		Me.Button3.Location = New System.Drawing.Point(433, 136)
		Me.Button3.Name = "Button3"
		Me.Button3.Size = New System.Drawing.Size(39, 21)
		Me.Button3.TabIndex = 14
		Me.Button3.Text = "Add"
		Me.Button3.UseVisualStyleBackColor = True
		'
		'ListTVGenres
		'
		Me.ListTVGenres.FormattingEnabled = True
		Me.ListTVGenres.Location = New System.Drawing.Point(235, 160)
		Me.ListTVGenres.Name = "ListTVGenres"
		Me.ListTVGenres.Size = New System.Drawing.Size(282, 108)
		Me.ListTVGenres.TabIndex = 13
		'
		'TVPosterPictureBox
		'
		Me.TVPosterPictureBox.InitialImage = CType(resources.GetObject("TVPosterPictureBox.InitialImage"), System.Drawing.Image)
		Me.TVPosterPictureBox.Location = New System.Drawing.Point(592, 170)
		Me.TVPosterPictureBox.Name = "TVPosterPictureBox"
		Me.TVPosterPictureBox.Size = New System.Drawing.Size(339, 465)
		Me.TVPosterPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.TVPosterPictureBox.TabIndex = 12
		Me.TVPosterPictureBox.TabStop = False
		'
		'TVShowLabel
		'
		Me.TVShowLabel.AutoSize = True
		Me.TVShowLabel.Location = New System.Drawing.Point(730, 22)
		Me.TVShowLabel.Name = "TVShowLabel"
		Me.TVShowLabel.Size = New System.Drawing.Size(39, 13)
		Me.TVShowLabel.TabIndex = 11
		Me.TVShowLabel.Text = "Label5"
		Me.TVShowLabel.Visible = False
		'
		'SaveTVShow
		'
		Me.SaveTVShow.Location = New System.Drawing.Point(235, 100)
		Me.SaveTVShow.Name = "SaveTVShow"
		Me.SaveTVShow.Size = New System.Drawing.Size(61, 28)
		Me.SaveTVShow.TabIndex = 10
		Me.SaveTVShow.Text = "Save"
		Me.SaveTVShow.UseVisualStyleBackColor = True
		'
		'txtShowLocation
		'
		Me.txtShowLocation.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtShowLocation.Location = New System.Drawing.Point(325, 73)
		Me.txtShowLocation.Name = "txtShowLocation"
		Me.txtShowLocation.Size = New System.Drawing.Size(279, 22)
		Me.txtShowLocation.TabIndex = 9
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label4.Location = New System.Drawing.Point(232, 73)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(81, 24)
		Me.Label4.TabIndex = 8
		Me.Label4.Text = "Location"
		'
		'TxtShowName
		'
		Me.TxtShowName.Enabled = False
		Me.TxtShowName.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TxtShowName.Location = New System.Drawing.Point(324, 6)
		Me.TxtShowName.Name = "TxtShowName"
		Me.TxtShowName.Size = New System.Drawing.Size(278, 26)
		Me.TxtShowName.TabIndex = 5
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label3.Location = New System.Drawing.Point(232, 39)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(79, 24)
		Me.Label3.TabIndex = 4
		Me.Label3.Text = "Network"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label2.Location = New System.Drawing.Point(231, 136)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(72, 24)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "Genres"
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!)
		Me.Label1.Location = New System.Drawing.Point(232, 11)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(58, 24)
		Me.Label1.TabIndex = 2
		Me.Label1.Text = "Show"
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(3, 615)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(57, 20)
		Me.Button1.TabIndex = 1
		Me.Button1.Text = "Refresh"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'TVShowList
		'
		Me.TVShowList.FullRowSelect = True
		Me.TVShowList.HideSelection = False
		Me.TVShowList.Location = New System.Drawing.Point(3, 3)
		Me.TVShowList.MultiSelect = False
		Me.TVShowList.Name = "TVShowList"
		Me.TVShowList.Size = New System.Drawing.Size(228, 606)
		Me.TVShowList.TabIndex = 0
		Me.TVShowList.UseCompatibleStateImageBehavior = False
		Me.TVShowList.View = System.Windows.Forms.View.Details
		'
		'TabPage5
		'
		Me.TabPage5.BackColor = System.Drawing.Color.Gray
		Me.TabPage5.Controls.Add(Me.AddMoviePosterButton)
		Me.TabPage5.Controls.Add(Me.MoviePosterSelect)
		Me.TabPage5.Controls.Add(Me.Label19)
		Me.TabPage5.Controls.Add(Me.ListMoviePosters)
		Me.TabPage5.Controls.Add(Me.Button18)
		Me.TabPage5.Controls.Add(Me.MovieIDLabel)
		Me.TabPage5.Controls.Add(Me.Button17)
		Me.TabPage5.Controls.Add(Me.txtMovieNetwork)
		Me.TabPage5.Controls.Add(Me.MovieLocation)
		Me.TabPage5.Controls.Add(Me.MovieLabel)
		Me.TabPage5.Controls.Add(Me.Button15)
		Me.TabPage5.Controls.Add(Me.Button16)
		Me.TabPage5.Controls.Add(Me.MovieGenresList)
		Me.TabPage5.Controls.Add(Me.Label13)
		Me.TabPage5.Controls.Add(Me.MovieList)
		Me.TabPage5.Controls.Add(Me.MoviePicture)
		Me.TabPage5.Location = New System.Drawing.Point(4, 22)
		Me.TabPage5.Name = "TabPage5"
		Me.TabPage5.Size = New System.Drawing.Size(992, 662)
		Me.TabPage5.TabIndex = 4
		Me.TabPage5.Text = "Movies"
		'
		'AddMoviePosterButton
		'
		Me.AddMoviePosterButton.Location = New System.Drawing.Point(483, 586)
		Me.AddMoviePosterButton.Name = "AddMoviePosterButton"
		Me.AddMoviePosterButton.Size = New System.Drawing.Size(39, 23)
		Me.AddMoviePosterButton.TabIndex = 29
		Me.AddMoviePosterButton.Text = "Add"
		Me.AddMoviePosterButton.UseVisualStyleBackColor = True
		'
		'MoviePosterSelect
		'
		Me.MoviePosterSelect.Location = New System.Drawing.Point(237, 586)
		Me.MoviePosterSelect.Name = "MoviePosterSelect"
		Me.MoviePosterSelect.Size = New System.Drawing.Size(73, 23)
		Me.MoviePosterSelect.TabIndex = 28
		Me.MoviePosterSelect.Text = "Save image"
		Me.MoviePosterSelect.UseVisualStyleBackColor = True
		'
		'Label19
		'
		Me.Label19.AutoSize = True
		Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.25!)
		Me.Label19.Location = New System.Drawing.Point(232, 298)
		Me.Label19.Name = "Label19"
		Me.Label19.Size = New System.Drawing.Size(174, 29)
		Me.Label19.TabIndex = 27
		Me.Label19.Text = "Movie Posters"
		Me.Label19.Visible = False
		'
		'ListMoviePosters
		'
		Me.ListMoviePosters.FormattingEnabled = True
		Me.ListMoviePosters.Location = New System.Drawing.Point(237, 329)
		Me.ListMoviePosters.Name = "ListMoviePosters"
		Me.ListMoviePosters.Size = New System.Drawing.Size(285, 251)
		Me.ListMoviePosters.TabIndex = 26
		'
		'Button18
		'
		Me.Button18.Location = New System.Drawing.Point(523, 47)
		Me.Button18.Name = "Button18"
		Me.Button18.Size = New System.Drawing.Size(33, 29)
		Me.Button18.TabIndex = 25
		Me.Button18.Text = "..."
		Me.Button18.UseVisualStyleBackColor = True
		'
		'MovieIDLabel
		'
		Me.MovieIDLabel.AutoSize = True
		Me.MovieIDLabel.Location = New System.Drawing.Point(590, 12)
		Me.MovieIDLabel.Name = "MovieIDLabel"
		Me.MovieIDLabel.Size = New System.Drawing.Size(45, 13)
		Me.MovieIDLabel.TabIndex = 24
		Me.MovieIDLabel.Text = "Label16"
		Me.MovieIDLabel.Visible = False
		'
		'Button17
		'
		Me.Button17.Location = New System.Drawing.Point(237, 107)
		Me.Button17.Name = "Button17"
		Me.Button17.Size = New System.Drawing.Size(44, 30)
		Me.Button17.TabIndex = 23
		Me.Button17.Text = "Save"
		Me.Button17.UseVisualStyleBackColor = True
		'
		'txtMovieNetwork
		'
		Me.txtMovieNetwork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.txtMovieNetwork.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.txtMovieNetwork.FormattingEnabled = True
		Me.txtMovieNetwork.Location = New System.Drawing.Point(237, 47)
		Me.txtMovieNetwork.Name = "txtMovieNetwork"
		Me.txtMovieNetwork.Size = New System.Drawing.Size(280, 28)
		Me.txtMovieNetwork.TabIndex = 22
		'
		'MovieLocation
		'
		Me.MovieLocation.Location = New System.Drawing.Point(237, 81)
		Me.MovieLocation.Name = "MovieLocation"
		Me.MovieLocation.Size = New System.Drawing.Size(280, 20)
		Me.MovieLocation.TabIndex = 21
		'
		'MovieLabel
		'
		Me.MovieLabel.AutoSize = True
		Me.MovieLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.MovieLabel.Location = New System.Drawing.Point(253, 12)
		Me.MovieLabel.Name = "MovieLabel"
		Me.MovieLabel.Size = New System.Drawing.Size(0, 25)
		Me.MovieLabel.TabIndex = 20
		'
		'Button15
		'
		Me.Button15.Location = New System.Drawing.Point(478, 150)
		Me.Button15.Name = "Button15"
		Me.Button15.Size = New System.Drawing.Size(39, 21)
		Me.Button15.TabIndex = 19
		Me.Button15.Text = "Del"
		Me.Button15.UseVisualStyleBackColor = True
		'
		'Button16
		'
		Me.Button16.Location = New System.Drawing.Point(433, 150)
		Me.Button16.Name = "Button16"
		Me.Button16.Size = New System.Drawing.Size(39, 21)
		Me.Button16.TabIndex = 18
		Me.Button16.Text = "Add"
		Me.Button16.UseVisualStyleBackColor = True
		'
		'MovieGenresList
		'
		Me.MovieGenresList.FormattingEnabled = True
		Me.MovieGenresList.Location = New System.Drawing.Point(237, 174)
		Me.MovieGenresList.Name = "MovieGenresList"
		Me.MovieGenresList.Size = New System.Drawing.Size(282, 121)
		Me.MovieGenresList.TabIndex = 17
		'
		'Label13
		'
		Me.Label13.AutoSize = True
		Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label13.Location = New System.Drawing.Point(232, 142)
		Me.Label13.Name = "Label13"
		Me.Label13.Size = New System.Drawing.Size(92, 29)
		Me.Label13.TabIndex = 16
		Me.Label13.Text = "Genres"
		'
		'MovieList
		'
		Me.MovieList.FullRowSelect = True
		Me.MovieList.HideSelection = False
		Me.MovieList.Location = New System.Drawing.Point(3, 3)
		Me.MovieList.MultiSelect = False
		Me.MovieList.Name = "MovieList"
		Me.MovieList.Size = New System.Drawing.Size(228, 606)
		Me.MovieList.TabIndex = 14
		Me.MovieList.UseCompatibleStateImageBehavior = False
		Me.MovieList.View = System.Windows.Forms.View.Details
		'
		'MoviePicture
		'
		Me.MoviePicture.InitialImage = CType(resources.GetObject("MoviePicture.InitialImage"), System.Drawing.Image)
		Me.MoviePicture.Location = New System.Drawing.Point(573, 67)
		Me.MoviePicture.Name = "MoviePicture"
		Me.MoviePicture.Size = New System.Drawing.Size(404, 542)
		Me.MoviePicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.MoviePicture.TabIndex = 13
		Me.MoviePicture.TabStop = False
		'
		'TabPage2
		'
		Me.TabPage2.BackColor = System.Drawing.Color.Gray
		Me.TabPage2.Controls.Add(Me.Label15)
		Me.TabPage2.Controls.Add(Me.MovieNetworkListSubList)
		Me.TabPage2.Controls.Add(Me.MovieNetworkList)
		Me.TabPage2.Controls.Add(Me.Label14)
		Me.TabPage2.Controls.Add(Me.NetworkListSubList)
		Me.TabPage2.Controls.Add(Me.NetworkList)
		Me.TabPage2.Location = New System.Drawing.Point(4, 22)
		Me.TabPage2.Name = "TabPage2"
		Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
		Me.TabPage2.Size = New System.Drawing.Size(992, 662)
		Me.TabPage2.TabIndex = 1
		Me.TabPage2.Text = "Networks / Studios"
		'
		'Label15
		'
		Me.Label15.BackColor = System.Drawing.Color.Silver
		Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label15.Location = New System.Drawing.Point(495, 6)
		Me.Label15.Name = "Label15"
		Me.Label15.Size = New System.Drawing.Size(278, 20)
		Me.Label15.TabIndex = 6
		Me.Label15.Text = "Movie Studios"
		Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'MovieNetworkListSubList
		'
		Me.MovieNetworkListSubList.FormattingEnabled = True
		Me.MovieNetworkListSubList.Location = New System.Drawing.Point(780, 29)
		Me.MovieNetworkListSubList.Name = "MovieNetworkListSubList"
		Me.MovieNetworkListSubList.Size = New System.Drawing.Size(211, 303)
		Me.MovieNetworkListSubList.TabIndex = 5
		'
		'MovieNetworkList
		'
		Me.MovieNetworkList.FullRowSelect = True
		Me.MovieNetworkList.HideSelection = False
		Me.MovieNetworkList.Location = New System.Drawing.Point(495, 29)
		Me.MovieNetworkList.Name = "MovieNetworkList"
		Me.MovieNetworkList.Size = New System.Drawing.Size(278, 586)
		Me.MovieNetworkList.TabIndex = 4
		Me.MovieNetworkList.UseCompatibleStateImageBehavior = False
		Me.MovieNetworkList.View = System.Windows.Forms.View.Details
		'
		'Label14
		'
		Me.Label14.BackColor = System.Drawing.Color.Silver
		Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label14.Location = New System.Drawing.Point(3, 6)
		Me.Label14.Name = "Label14"
		Me.Label14.Size = New System.Drawing.Size(268, 20)
		Me.Label14.TabIndex = 3
		Me.Label14.Text = "TV Networks"
		Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'NetworkListSubList
		'
		Me.NetworkListSubList.FormattingEnabled = True
		Me.NetworkListSubList.Location = New System.Drawing.Point(278, 29)
		Me.NetworkListSubList.Name = "NetworkListSubList"
		Me.NetworkListSubList.Size = New System.Drawing.Size(211, 303)
		Me.NetworkListSubList.TabIndex = 2
		'
		'NetworkList
		'
		Me.NetworkList.FullRowSelect = True
		Me.NetworkList.HideSelection = False
		Me.NetworkList.Location = New System.Drawing.Point(3, 29)
		Me.NetworkList.Name = "NetworkList"
		Me.NetworkList.Size = New System.Drawing.Size(267, 586)
		Me.NetworkList.TabIndex = 1
		Me.NetworkList.UseCompatibleStateImageBehavior = False
		Me.NetworkList.View = System.Windows.Forms.View.Details
		'
		'TabPage3
		'
		Me.TabPage3.BackColor = System.Drawing.Color.Gray
		Me.TabPage3.Controls.Add(Me.Label17)
		Me.TabPage3.Controls.Add(Me.Label16)
		Me.TabPage3.Controls.Add(Me.GenresListSubListMovies)
		Me.TabPage3.Controls.Add(Me.GenresListSubList)
		Me.TabPage3.Controls.Add(Me.GenresList)
		Me.TabPage3.Location = New System.Drawing.Point(4, 22)
		Me.TabPage3.Name = "TabPage3"
		Me.TabPage3.Size = New System.Drawing.Size(992, 662)
		Me.TabPage3.TabIndex = 2
		Me.TabPage3.Text = "Genres"
		'
		'Label17
		'
		Me.Label17.BackColor = System.Drawing.Color.Silver
		Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label17.Location = New System.Drawing.Point(720, 13)
		Me.Label17.Name = "Label17"
		Me.Label17.Size = New System.Drawing.Size(205, 20)
		Me.Label17.TabIndex = 6
		Me.Label17.Text = "Movies"
		Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'Label16
		'
		Me.Label16.BackColor = System.Drawing.Color.Silver
		Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label16.Location = New System.Drawing.Point(355, 13)
		Me.Label16.Name = "Label16"
		Me.Label16.Size = New System.Drawing.Size(205, 20)
		Me.Label16.TabIndex = 5
		Me.Label16.Text = "TV Shows"
		Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'GenresListSubListMovies
		'
		Me.GenresListSubListMovies.FormattingEnabled = True
		Me.GenresListSubListMovies.Location = New System.Drawing.Point(720, 35)
		Me.GenresListSubListMovies.Name = "GenresListSubListMovies"
		Me.GenresListSubListMovies.Size = New System.Drawing.Size(205, 407)
		Me.GenresListSubListMovies.TabIndex = 4
		'
		'GenresListSubList
		'
		Me.GenresListSubList.FormattingEnabled = True
		Me.GenresListSubList.Location = New System.Drawing.Point(355, 35)
		Me.GenresListSubList.Name = "GenresListSubList"
		Me.GenresListSubList.Size = New System.Drawing.Size(205, 407)
		Me.GenresListSubList.TabIndex = 3
		'
		'GenresList
		'
		Me.GenresList.FullRowSelect = True
		Me.GenresList.HideSelection = False
		Me.GenresList.Location = New System.Drawing.Point(3, 3)
		Me.GenresList.Name = "GenresList"
		Me.GenresList.Size = New System.Drawing.Size(325, 618)
		Me.GenresList.Sorting = System.Windows.Forms.SortOrder.Ascending
		Me.GenresList.TabIndex = 2
		Me.GenresList.UseCompatibleStateImageBehavior = False
		Me.GenresList.View = System.Windows.Forms.View.Details
		'
		'TabPage4
		'
		Me.TabPage4.BackColor = System.Drawing.Color.Gray
		Me.TabPage4.Controls.Add(Me.DelExcludeBtn)
		Me.TabPage4.Controls.Add(Me.SaveExcludeBtn)
		Me.TabPage4.Controls.Add(Me.AddExcludeBtn)
		Me.TabPage4.Controls.Add(Me.GDataDemoLink)
		Me.TabPage4.Controls.Add(Me.SortTypeBox)
		Me.TabPage4.Controls.Add(Me.SortType)
		Me.TabPage4.Controls.Add(Me.MediaLimitBox)
		Me.TabPage4.Controls.Add(Me.MediaLimit)
		Me.TabPage4.Controls.Add(Me.ShowDescBox)
		Me.TabPage4.Controls.Add(Me.ShowDesc)
		Me.TabPage4.Controls.Add(Me.ShowTitleBox)
		Me.TabPage4.Controls.Add(Me.ShowTitle)
		Me.TabPage4.Controls.Add(Me.YouTubeType)
		Me.TabPage4.Controls.Add(Me.StrmUrlBox)
		Me.TabPage4.Controls.Add(Me.StrmUrl)
		Me.TabPage4.Controls.Add(Me.TVGuideSubMenu)
		Me.TabPage4.Controls.Add(Me.TVGuideShowName)
		Me.TabPage4.Controls.Add(Me.Button13)
		Me.TabPage4.Controls.Add(Me.Button14)
		Me.TabPage4.Controls.Add(Me.Button11)
		Me.TabPage4.Controls.Add(Me.Button12)
		Me.TabPage4.Controls.Add(Me.Button9)
		Me.TabPage4.Controls.Add(Me.Button10)
		Me.TabPage4.Controls.Add(Me.Button8)
		Me.TabPage4.Controls.Add(Me.Button7)
		Me.TabPage4.Controls.Add(Me.Button2)
		Me.TabPage4.Controls.Add(Me.NotShows)
		Me.TabPage4.Controls.Add(Me.Label12)
		Me.TabPage4.Controls.Add(Me.SchedulingList)
		Me.TabPage4.Controls.Add(Me.Label11)
		Me.TabPage4.Controls.Add(Me.InterleavedList)
		Me.TabPage4.Controls.Add(Me.Label7)
		Me.TabPage4.Controls.Add(Me.ResetDays)
		Me.TabPage4.Controls.Add(Me.Label10)
		Me.TabPage4.Controls.Add(Me.ChannelName)
		Me.TabPage4.Controls.Add(Me.Label9)
		Me.TabPage4.Controls.Add(Me.ChkPlayInOrder)
		Me.TabPage4.Controls.Add(Me.ChkPause)
		Me.TabPage4.Controls.Add(Me.ChkWatched)
		Me.TabPage4.Controls.Add(Me.ChkUnwatched)
		Me.TabPage4.Controls.Add(Me.ChkIceLibrary)
		Me.TabPage4.Controls.Add(Me.ChkExcludeBCT)
		Me.TabPage4.Controls.Add(Me.ChkPopup)
		Me.TabPage4.Controls.Add(Me.ChkResume)
		Me.TabPage4.Controls.Add(Me.ChkRealTime)
		Me.TabPage4.Controls.Add(Me.ChkRandom)
		Me.TabPage4.Controls.Add(Me.chkDontPlayChannel)
		Me.TabPage4.Controls.Add(Me.ChkLogo)
		Me.TabPage4.Controls.Add(Me.Label8)
		Me.TabPage4.Controls.Add(Me.Option2)
		Me.TabPage4.Controls.Add(Me.Button5)
		Me.TabPage4.Controls.Add(Me.PlayListLocation)
		Me.TabPage4.Controls.Add(Me.Label6)
		Me.TabPage4.Controls.Add(Me.Label5)
		Me.TabPage4.Controls.Add(Me.PlayListType)
		Me.TabPage4.Controls.Add(Me.TVGuideList)
		Me.TabPage4.Controls.Add(Me.PluginType)
		Me.TabPage4.Controls.Add(Me.SubChannelType)
		Me.TabPage4.ForeColor = System.Drawing.SystemColors.ControlText
		Me.TabPage4.Location = New System.Drawing.Point(4, 22)
		Me.TabPage4.Name = "TabPage4"
		Me.TabPage4.Size = New System.Drawing.Size(992, 662)
		Me.TabPage4.TabIndex = 3
		Me.TabPage4.Text = "TV Guide"
		'
		'DelExcludeBtn
		'
		Me.DelExcludeBtn.Location = New System.Drawing.Point(910, 610)
		Me.DelExcludeBtn.Name = "DelExcludeBtn"
		Me.DelExcludeBtn.Size = New System.Drawing.Size(39, 22)
		Me.DelExcludeBtn.TabIndex = 61
		Me.DelExcludeBtn.Text = "Del"
		Me.DelExcludeBtn.UseVisualStyleBackColor = True
		Me.DelExcludeBtn.Visible = False
		'
		'SaveExcludeBtn
		'
		Me.SaveExcludeBtn.Location = New System.Drawing.Point(935, 224)
		Me.SaveExcludeBtn.Name = "SaveExcludeBtn"
		Me.SaveExcludeBtn.Size = New System.Drawing.Size(49, 22)
		Me.SaveExcludeBtn.TabIndex = 60
		Me.SaveExcludeBtn.Text = "Save"
		Me.SaveExcludeBtn.UseVisualStyleBackColor = True
		Me.SaveExcludeBtn.Visible = False
		'
		'AddExcludeBtn
		'
		Me.AddExcludeBtn.Location = New System.Drawing.Point(866, 610)
		Me.AddExcludeBtn.Name = "AddExcludeBtn"
		Me.AddExcludeBtn.Size = New System.Drawing.Size(39, 22)
		Me.AddExcludeBtn.TabIndex = 58
		Me.AddExcludeBtn.Text = "Add"
		Me.AddExcludeBtn.UseVisualStyleBackColor = True
		Me.AddExcludeBtn.Visible = False
		'
		'GDataDemoLink
		'
		Me.GDataDemoLink.AutoSize = True
		Me.GDataDemoLink.Location = New System.Drawing.Point(444, 89)
		Me.GDataDemoLink.Name = "GDataDemoLink"
		Me.GDataDemoLink.Size = New System.Drawing.Size(69, 13)
		Me.GDataDemoLink.TabIndex = 56
		Me.GDataDemoLink.TabStop = True
		Me.GDataDemoLink.Text = "GData Demo"
		Me.GDataDemoLink.Visible = False
		'
		'SortTypeBox
		'
		Me.SortTypeBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.SortTypeBox.FormattingEnabled = True
		Me.SortTypeBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
		Me.SortTypeBox.Items.AddRange(New Object() {"Default", "Random", "Reverse"})
		Me.SortTypeBox.Location = New System.Drawing.Point(522, 222)
		Me.SortTypeBox.Name = "SortTypeBox"
		Me.SortTypeBox.Size = New System.Drawing.Size(103, 21)
		Me.SortTypeBox.TabIndex = 54
		Me.SortTypeBox.Visible = False
		'
		'SortType
		'
		Me.SortType.AutoSize = True
		Me.SortType.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.SortType.Location = New System.Drawing.Point(518, 201)
		Me.SortType.Name = "SortType"
		Me.SortType.Size = New System.Drawing.Size(93, 20)
		Me.SortType.TabIndex = 53
		Me.SortType.Text = "Sort Order:"
		Me.SortType.Visible = False
		'
		'MediaLimitBox
		'
		Me.MediaLimitBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.MediaLimitBox.FormattingEnabled = True
		Me.MediaLimitBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
		Me.MediaLimitBox.Items.AddRange(New Object() {"25", "50", "100", "150", "200", "250", "500", "1000"})
		Me.MediaLimitBox.Location = New System.Drawing.Point(413, 222)
		Me.MediaLimitBox.Name = "MediaLimitBox"
		Me.MediaLimitBox.Size = New System.Drawing.Size(61, 21)
		Me.MediaLimitBox.TabIndex = 52
		Me.MediaLimitBox.Visible = False
		'
		'MediaLimit
		'
		Me.MediaLimit.AutoSize = True
		Me.MediaLimit.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.MediaLimit.Location = New System.Drawing.Point(409, 201)
		Me.MediaLimit.Name = "MediaLimit"
		Me.MediaLimit.Size = New System.Drawing.Size(51, 20)
		Me.MediaLimit.TabIndex = 51
		Me.MediaLimit.Text = "Limit:"
		Me.MediaLimit.Visible = False
		'
		'ShowDescBox
		'
		Me.ShowDescBox.Location = New System.Drawing.Point(158, 247)
		Me.ShowDescBox.Name = "ShowDescBox"
		Me.ShowDescBox.Size = New System.Drawing.Size(468, 20)
		Me.ShowDescBox.TabIndex = 49
		Me.ShowDescBox.Visible = False
		'
		'ShowDesc
		'
		Me.ShowDesc.AutoSize = True
		Me.ShowDesc.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.ShowDesc.Location = New System.Drawing.Point(154, 226)
		Me.ShowDesc.Name = "ShowDesc"
		Me.ShowDesc.Size = New System.Drawing.Size(146, 20)
		Me.ShowDesc.TabIndex = 48
		Me.ShowDesc.Text = "Show Description:"
		Me.ShowDesc.Visible = False
		'
		'ShowTitleBox
		'
		Me.ShowTitleBox.Location = New System.Drawing.Point(157, 203)
		Me.ShowTitleBox.Name = "ShowTitleBox"
		Me.ShowTitleBox.Size = New System.Drawing.Size(129, 20)
		Me.ShowTitleBox.TabIndex = 47
		Me.ShowTitleBox.Visible = False
		'
		'ShowTitle
		'
		Me.ShowTitle.AutoSize = True
		Me.ShowTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.ShowTitle.Location = New System.Drawing.Point(153, 180)
		Me.ShowTitle.Name = "ShowTitle"
		Me.ShowTitle.Size = New System.Drawing.Size(92, 20)
		Me.ShowTitle.TabIndex = 46
		Me.ShowTitle.Text = "Show Title:"
		Me.ShowTitle.Visible = False
		'
		'YouTubeType
		'
		Me.YouTubeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.YouTubeType.FormattingEnabled = True
		Me.YouTubeType.ImeMode = System.Windows.Forms.ImeMode.NoControl
		Me.YouTubeType.Items.AddRange(New Object() {"Channel/User", "Playlist", "New Subs", "Favorites", "Search (Safe)", "Blank", "Multi Youtube Playlist", "Multi Youtube Channel", "Raw"})
		Me.YouTubeType.Location = New System.Drawing.Point(227, 86)
		Me.YouTubeType.Name = "YouTubeType"
		Me.YouTubeType.Size = New System.Drawing.Size(211, 21)
		Me.YouTubeType.TabIndex = 45
		Me.YouTubeType.Visible = False
		'
		'StrmUrlBox
		'
		Me.StrmUrlBox.Location = New System.Drawing.Point(267, 144)
		Me.StrmUrlBox.Name = "StrmUrlBox"
		Me.StrmUrlBox.Size = New System.Drawing.Size(374, 20)
		Me.StrmUrlBox.TabIndex = 44
		Me.StrmUrlBox.Visible = False
		'
		'StrmUrl
		'
		Me.StrmUrl.Anchor = System.Windows.Forms.AnchorStyles.None
		Me.StrmUrl.AutoSize = True
		Me.StrmUrl.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.StrmUrl.Location = New System.Drawing.Point(154, 142)
		Me.StrmUrl.Name = "StrmUrl"
		Me.StrmUrl.Size = New System.Drawing.Size(106, 20)
		Me.StrmUrl.TabIndex = 43
		Me.StrmUrl.Text = "Source Path:"
		Me.StrmUrl.Visible = False
		'
		'TVGuideSubMenu
		'
		Me.TVGuideSubMenu.Location = New System.Drawing.Point(159, 290)
		Me.TVGuideSubMenu.Name = "TVGuideSubMenu"
		Me.TVGuideSubMenu.Size = New System.Drawing.Size(192, 314)
		Me.TVGuideSubMenu.TabIndex = 42
		Me.TVGuideSubMenu.UseCompatibleStateImageBehavior = False
		Me.TVGuideSubMenu.View = System.Windows.Forms.View.Details
		Me.TVGuideSubMenu.Visible = False
		'
		'TVGuideShowName
		'
		Me.TVGuideShowName.AutoSize = True
		Me.TVGuideShowName.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.TVGuideShowName.Location = New System.Drawing.Point(166, 13)
		Me.TVGuideShowName.Name = "TVGuideShowName"
		Me.TVGuideShowName.Size = New System.Drawing.Size(0, 24)
		Me.TVGuideShowName.TabIndex = 41
		'
		'Button13
		'
		Me.Button13.Location = New System.Drawing.Point(58, 610)
		Me.Button13.Name = "Button13"
		Me.Button13.Size = New System.Drawing.Size(39, 22)
		Me.Button13.TabIndex = 40
		Me.Button13.Text = "Del"
		Me.Button13.UseVisualStyleBackColor = True
		'
		'Button14
		'
		Me.Button14.Location = New System.Drawing.Point(9, 610)
		Me.Button14.Name = "Button14"
		Me.Button14.Size = New System.Drawing.Size(39, 22)
		Me.Button14.TabIndex = 39
		Me.Button14.Text = "Add"
		Me.Button14.UseVisualStyleBackColor = True
		'
		'Button11
		'
		Me.Button11.Location = New System.Drawing.Point(821, 610)
		Me.Button11.Name = "Button11"
		Me.Button11.Size = New System.Drawing.Size(39, 22)
		Me.Button11.TabIndex = 38
		Me.Button11.Text = "Del"
		Me.Button11.UseVisualStyleBackColor = True
		Me.Button11.Visible = False
		'
		'Button12
		'
		Me.Button12.Location = New System.Drawing.Point(776, 610)
		Me.Button12.Name = "Button12"
		Me.Button12.Size = New System.Drawing.Size(39, 22)
		Me.Button12.TabIndex = 37
		Me.Button12.Text = "Add"
		Me.Button12.UseVisualStyleBackColor = True
		Me.Button12.Visible = False
		'
		'Button9
		'
		Me.Button9.Location = New System.Drawing.Point(610, 610)
		Me.Button9.Name = "Button9"
		Me.Button9.Size = New System.Drawing.Size(39, 22)
		Me.Button9.TabIndex = 36
		Me.Button9.Text = "Del"
		Me.Button9.UseVisualStyleBackColor = True
		Me.Button9.Visible = False
		'
		'Button10
		'
		Me.Button10.Location = New System.Drawing.Point(564, 610)
		Me.Button10.Name = "Button10"
		Me.Button10.Size = New System.Drawing.Size(39, 22)
		Me.Button10.TabIndex = 35
		Me.Button10.Text = "Add"
		Me.Button10.UseVisualStyleBackColor = True
		Me.Button10.Visible = False
		'
		'Button8
		'
		Me.Button8.Location = New System.Drawing.Point(409, 610)
		Me.Button8.Name = "Button8"
		Me.Button8.Size = New System.Drawing.Size(39, 22)
		Me.Button8.TabIndex = 34
		Me.Button8.Text = "Del"
		Me.Button8.UseVisualStyleBackColor = True
		Me.Button8.Visible = False
		'
		'Button7
		'
		Me.Button7.Location = New System.Drawing.Point(361, 610)
		Me.Button7.Name = "Button7"
		Me.Button7.Size = New System.Drawing.Size(39, 22)
		Me.Button7.TabIndex = 33
		Me.Button7.Text = "Add"
		Me.Button7.UseVisualStyleBackColor = True
		Me.Button7.Visible = False
		'
		'Button2
		'
		Me.Button2.Location = New System.Drawing.Point(105, 610)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(48, 22)
		Me.Button2.TabIndex = 32
		Me.Button2.Text = "Save"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'NotShows
		'
		Me.NotShows.FormattingEnabled = True
		Me.NotShows.Location = New System.Drawing.Point(778, 290)
		Me.NotShows.Name = "NotShows"
		Me.NotShows.Size = New System.Drawing.Size(171, 316)
		Me.NotShows.TabIndex = 31
		Me.NotShows.Visible = False
		'
		'Label12
		'
		Me.Label12.AutoSize = True
		Me.Label12.Location = New System.Drawing.Point(797, 270)
		Me.Label12.Name = "Label12"
		Me.Label12.Size = New System.Drawing.Size(135, 13)
		Me.Label12.TabIndex = 30
		Me.Label12.Text = "Don't Include these shows:"
		Me.Label12.Visible = False
		'
		'SchedulingList
		'
		Me.SchedulingList.FullRowSelect = True
		Me.SchedulingList.Location = New System.Drawing.Point(566, 290)
		Me.SchedulingList.Name = "SchedulingList"
		Me.SchedulingList.Size = New System.Drawing.Size(206, 314)
		Me.SchedulingList.TabIndex = 29
		Me.SchedulingList.UseCompatibleStateImageBehavior = False
		Me.SchedulingList.View = System.Windows.Forms.View.Details
		Me.SchedulingList.Visible = False
		'
		'Label11
		'
		Me.Label11.AutoSize = True
		Me.Label11.Location = New System.Drawing.Point(620, 270)
		Me.Label11.Name = "Label11"
		Me.Label11.Size = New System.Drawing.Size(102, 13)
		Me.Label11.TabIndex = 28
		Me.Label11.Text = "Channel Scheduling"
		Me.Label11.Visible = False
		'
		'InterleavedList
		'
		Me.InterleavedList.FullRowSelect = True
		Me.InterleavedList.Location = New System.Drawing.Point(361, 290)
		Me.InterleavedList.Name = "InterleavedList"
		Me.InterleavedList.Size = New System.Drawing.Size(200, 314)
		Me.InterleavedList.TabIndex = 27
		Me.InterleavedList.UseCompatibleStateImageBehavior = False
		Me.InterleavedList.View = System.Windows.Forms.View.Details
		Me.InterleavedList.Visible = False
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Location = New System.Drawing.Point(410, 270)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(107, 13)
		Me.Label7.TabIndex = 26
		Me.Label7.Text = "Interleaved Channels"
		Me.Label7.Visible = False
		'
		'ResetDays
		'
		Me.ResetDays.Location = New System.Drawing.Point(862, 149)
		Me.ResetDays.Name = "ResetDays"
		Me.ResetDays.Size = New System.Drawing.Size(112, 20)
		Me.ResetDays.TabIndex = 25
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Location = New System.Drawing.Point(860, 132)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(106, 13)
		Me.Label10.TabIndex = 24
		Me.Label10.Text = "Reset Every X Hours"
		'
		'ChannelName
		'
		Me.ChannelName.Location = New System.Drawing.Point(227, 37)
		Me.ChannelName.Name = "ChannelName"
		Me.ChannelName.Size = New System.Drawing.Size(211, 20)
		Me.ChannelName.TabIndex = 23
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.Label9.Location = New System.Drawing.Point(159, 37)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(58, 20)
		Me.Label9.TabIndex = 22
		Me.Label9.Text = "Name:"
		'
		'ChkPlayInOrder
		'
		Me.ChkPlayInOrder.AutoSize = True
		Me.ChkPlayInOrder.Location = New System.Drawing.Point(841, 82)
		Me.ChkPlayInOrder.Name = "ChkPlayInOrder"
		Me.ChkPlayInOrder.Size = New System.Drawing.Size(117, 17)
		Me.ChkPlayInOrder.TabIndex = 21
		Me.ChkPlayInOrder.Text = "Play shows in order"
		Me.ChkPlayInOrder.UseVisualStyleBackColor = True
		'
		'ChkPause
		'
		Me.ChkPause.AutoSize = True
		Me.ChkPause.Location = New System.Drawing.Point(841, 60)
		Me.ChkPause.Name = "ChkPause"
		Me.ChkPause.Size = New System.Drawing.Size(149, 17)
		Me.ChkPause.TabIndex = 20
		Me.ChkPause.Text = "Pause when not watching"
		Me.ChkPause.UseVisualStyleBackColor = True
		'
		'ChkWatched
		'
		Me.ChkWatched.AutoSize = True
		Me.ChkWatched.Location = New System.Drawing.Point(716, 105)
		Me.ChkWatched.Name = "ChkWatched"
		Me.ChkWatched.Size = New System.Drawing.Size(113, 17)
		Me.ChkWatched.TabIndex = 19
		Me.ChkWatched.Text = "Only play watched"
		Me.ChkWatched.UseVisualStyleBackColor = True
		'
		'ChkUnwatched
		'
		Me.ChkUnwatched.AutoSize = True
		Me.ChkUnwatched.Location = New System.Drawing.Point(716, 82)
		Me.ChkUnwatched.Name = "ChkUnwatched"
		Me.ChkUnwatched.Size = New System.Drawing.Size(125, 17)
		Me.ChkUnwatched.TabIndex = 18
		Me.ChkUnwatched.Text = "Only play unwatched"
		Me.ChkUnwatched.UseVisualStyleBackColor = True
		'
		'ChkIceLibrary
		'
		Me.ChkIceLibrary.AutoSize = True
		Me.ChkIceLibrary.Location = New System.Drawing.Point(716, 128)
		Me.ChkIceLibrary.Name = "ChkIceLibrary"
		Me.ChkIceLibrary.Size = New System.Drawing.Size(99, 17)
		Me.ChkIceLibrary.TabIndex = 17
		Me.ChkIceLibrary.Text = "Exclude Strms?"
		Me.ChkIceLibrary.UseVisualStyleBackColor = True
		'
		'ChkExcludeBCT
		'
		Me.ChkExcludeBCT.AutoSize = True
		Me.ChkExcludeBCT.Location = New System.Drawing.Point(716, 151)
		Me.ChkExcludeBCT.Name = "ChkExcludeBCT"
		Me.ChkExcludeBCT.Size = New System.Drawing.Size(101, 17)
		Me.ChkExcludeBCT.TabIndex = 17
		Me.ChkExcludeBCT.Text = "Exclude BCT's?"
		Me.ChkExcludeBCT.UseVisualStyleBackColor = True
		'
		'ChkPopup
		'
		Me.ChkPopup.AutoSize = True
		Me.ChkPopup.Location = New System.Drawing.Point(716, 174)
		Me.ChkPopup.Name = "ChkPopup"
		Me.ChkPopup.Size = New System.Drawing.Size(153, 17)
		Me.ChkPopup.TabIndex = 17
		Me.ChkPopup.Text = "Disable ComingUp Popup?"
		Me.ChkPopup.UseVisualStyleBackColor = True
		'
		'ChkResume
		'
		Me.ChkResume.AutoSize = True
		Me.ChkResume.Location = New System.Drawing.Point(716, 59)
		Me.ChkResume.Name = "ChkResume"
		Me.ChkResume.Size = New System.Drawing.Size(119, 17)
		Me.ChkResume.TabIndex = 16
		Me.ChkResume.Text = "Force resume mode"
		Me.ChkResume.UseVisualStyleBackColor = True
		'
		'ChkRealTime
		'
		Me.ChkRealTime.AutoSize = True
		Me.ChkRealTime.Location = New System.Drawing.Point(841, 36)
		Me.ChkRealTime.Name = "ChkRealTime"
		Me.ChkRealTime.Size = New System.Drawing.Size(124, 17)
		Me.ChkRealTime.TabIndex = 15
		Me.ChkRealTime.Text = "Force real-time mode"
		Me.ChkRealTime.UseVisualStyleBackColor = True
		'
		'ChkRandom
		'
		Me.ChkRandom.AutoSize = True
		Me.ChkRandom.Location = New System.Drawing.Point(716, 36)
		Me.ChkRandom.Name = "ChkRandom"
		Me.ChkRandom.Size = New System.Drawing.Size(120, 17)
		Me.ChkRandom.TabIndex = 14
		Me.ChkRandom.Text = "Force random mode"
		Me.ChkRandom.UseVisualStyleBackColor = True
		'
		'chkDontPlayChannel
		'
		Me.chkDontPlayChannel.AutoSize = True
		Me.chkDontPlayChannel.Location = New System.Drawing.Point(841, 13)
		Me.chkDontPlayChannel.Name = "chkDontPlayChannel"
		Me.chkDontPlayChannel.Size = New System.Drawing.Size(133, 17)
		Me.chkDontPlayChannel.TabIndex = 13
		Me.chkDontPlayChannel.Text = "Don't play this channel"
		Me.chkDontPlayChannel.UseVisualStyleBackColor = True
		'
		'ChkLogo
		'
		Me.ChkLogo.AutoSize = True
		Me.ChkLogo.Location = New System.Drawing.Point(716, 13)
		Me.ChkLogo.Name = "ChkLogo"
		Me.ChkLogo.Size = New System.Drawing.Size(83, 17)
		Me.ChkLogo.TabIndex = 12
		Me.ChkLogo.Text = "Display logo"
		Me.ChkLogo.UseVisualStyleBackColor = True
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.Location = New System.Drawing.Point(153, 40)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(0, 24)
		Me.Label8.TabIndex = 10
		'
		'Option2
		'
		Me.Option2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.Option2.FormattingEnabled = True
		Me.Option2.Location = New System.Drawing.Point(227, 86)
		Me.Option2.Name = "Option2"
		Me.Option2.Size = New System.Drawing.Size(211, 21)
		Me.Option2.TabIndex = 9
		'
		'Button5
		'
		Me.Button5.Location = New System.Drawing.Point(586, 119)
		Me.Button5.Name = "Button5"
		Me.Button5.Size = New System.Drawing.Size(54, 20)
		Me.Button5.TabIndex = 6
		Me.Button5.Text = "Select"
		Me.Button5.UseVisualStyleBackColor = True
		Me.Button5.Visible = False
		'
		'PlayListLocation
		'
		Me.PlayListLocation.Location = New System.Drawing.Point(267, 120)
		Me.PlayListLocation.Name = "PlayListLocation"
		Me.PlayListLocation.Size = New System.Drawing.Size(315, 20)
		Me.PlayListLocation.TabIndex = 5
		Me.PlayListLocation.Visible = False
		'
		'Label6
		'
		Me.Label6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
			Or System.Windows.Forms.AnchorStyles.Left) _
			Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.Label6.AutoSize = True
		Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.Label6.Location = New System.Drawing.Point(154, 119)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(78, 20)
		Me.Label6.TabIndex = 4
		Me.Label6.Text = "Location:"
		Me.Label6.Visible = False
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
		Me.Label5.Location = New System.Drawing.Point(159, 60)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(50, 20)
		Me.Label5.TabIndex = 3
		Me.Label5.Text = "Type:"
		'
		'PlayListType
		'
		Me.PlayListType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.PlayListType.FormattingEnabled = True
		Me.PlayListType.Items.AddRange(New Object() {"Playlist", "TV Network", "Movie Studio", "TV Genre", "Movie Genre", "Mixed Genre (TV & Movie)", "TV Show", "Directory", "LiveTV", "InternetTV", "YouTubeTV", "RSS", "Music (WIP)", "Music Videos", "Extras (VIP Exclusive)", "Direct Plugin (WIP)", "Direct Playon (WIP)"})
		Me.PlayListType.Location = New System.Drawing.Point(227, 62)
		Me.PlayListType.Name = "PlayListType"
		Me.PlayListType.Size = New System.Drawing.Size(211, 21)
		Me.PlayListType.TabIndex = 2
		'
		'TVGuideList
		'
		Me.TVGuideList.FullRowSelect = True
		Me.TVGuideList.HideSelection = False
		Me.TVGuideList.Location = New System.Drawing.Point(3, 3)
		Me.TVGuideList.Name = "TVGuideList"
		Me.TVGuideList.Size = New System.Drawing.Size(149, 601)
		Me.TVGuideList.Sorting = System.Windows.Forms.SortOrder.Ascending
		Me.TVGuideList.TabIndex = 1
		Me.TVGuideList.UseCompatibleStateImageBehavior = False
		Me.TVGuideList.View = System.Windows.Forms.View.Details
		'
		'PluginType
		'
		Me.PluginType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.PluginType.FormattingEnabled = True
		Me.PluginType.Location = New System.Drawing.Point(227, 86)
		Me.PluginType.Name = "PluginType"
		Me.PluginType.Size = New System.Drawing.Size(211, 21)
		Me.PluginType.TabIndex = 57
		Me.PluginType.Visible = False
		'
		'SubChannelType
		'
		Me.SubChannelType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.SubChannelType.FormattingEnabled = True
		Me.SubChannelType.ImeMode = System.Windows.Forms.ImeMode.NoControl
		Me.SubChannelType.Location = New System.Drawing.Point(227, 86)
		Me.SubChannelType.Name = "SubChannelType"
		Me.SubChannelType.Size = New System.Drawing.Size(211, 21)
		Me.SubChannelType.TabIndex = 55
		Me.SubChannelType.Visible = False
		'
		'TabPage6
		'
		Me.TabPage6.BackColor = System.Drawing.Color.Gray
		Me.TabPage6.Controls.Add(Me.Label24)
		Me.TabPage6.Controls.Add(Me.Label23)
		Me.TabPage6.Controls.Add(Me.LunaDonatePic)
		Me.TabPage6.Controls.Add(Me.Label22)
		Me.TabPage6.Controls.Add(Me.PeppyDonatePic)
		Me.TabPage6.Controls.Add(Me.PeppyDonate)
		Me.TabPage6.Controls.Add(Me.HelpLink)
		Me.TabPage6.Controls.Add(Me.Label21)
		Me.TabPage6.Controls.Add(Me.HelpList)
		Me.TabPage6.Location = New System.Drawing.Point(4, 22)
		Me.TabPage6.Name = "TabPage6"
		Me.TabPage6.Size = New System.Drawing.Size(992, 662)
		Me.TabPage6.TabIndex = 5
		Me.TabPage6.Text = "About/Help"
		'
		'Label24
		'
		Me.Label24.AutoSize = True
		Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!)
		Me.Label24.ForeColor = System.Drawing.Color.Navy
		Me.Label24.Location = New System.Drawing.Point(8, 42)
		Me.Label24.Name = "Label24"
		Me.Label24.Size = New System.Drawing.Size(220, 18)
		Me.Label24.TabIndex = 8
		Me.Label24.Text = "(Make a selection and click Go!)"
		'
		'Label23
		'
		Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
		Me.Label23.ForeColor = System.Drawing.Color.Navy
		Me.Label23.Location = New System.Drawing.Point(351, 11)
		Me.Label23.Name = "Label23"
		Me.Label23.Size = New System.Drawing.Size(512, 84)
		Me.Label23.TabIndex = 7
		Me.Label23.Text = "Many hours have been put into PseudoTVLive and PseudoTVLive Manager. Donate?"
		Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'LunaDonatePic
		'
		Me.LunaDonatePic.ImageLocation = "https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif"
		Me.LunaDonatePic.InitialImage = Nothing
		Me.LunaDonatePic.Location = New System.Drawing.Point(696, 136)
		Me.LunaDonatePic.Name = "LunaDonatePic"
		Me.LunaDonatePic.Size = New System.Drawing.Size(134, 28)
		Me.LunaDonatePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.LunaDonatePic.TabIndex = 6
		Me.LunaDonatePic.TabStop = False
		'
		'Label22
		'
		Me.Label22.AutoSize = True
		Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
		Me.Label22.ForeColor = System.Drawing.Color.Navy
		Me.Label22.Location = New System.Drawing.Point(721, 109)
		Me.Label22.Name = "Label22"
		Me.Label22.Size = New System.Drawing.Size(79, 24)
		Me.Label22.TabIndex = 5
		Me.Label22.Text = "Lunatixz"
		'
		'PeppyDonatePic
		'
		Me.PeppyDonatePic.ImageLocation = "https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif"
		Me.PeppyDonatePic.Location = New System.Drawing.Point(388, 136)
		Me.PeppyDonatePic.Name = "PeppyDonatePic"
		Me.PeppyDonatePic.Size = New System.Drawing.Size(134, 29)
		Me.PeppyDonatePic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
		Me.PeppyDonatePic.TabIndex = 4
		Me.PeppyDonatePic.TabStop = False
		'
		'PeppyDonate
		'
		Me.PeppyDonate.AutoSize = True
		Me.PeppyDonate.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
		Me.PeppyDonate.ForeColor = System.Drawing.Color.Navy
		Me.PeppyDonate.Location = New System.Drawing.Point(401, 109)
		Me.PeppyDonate.Name = "PeppyDonate"
		Me.PeppyDonate.Size = New System.Drawing.Size(104, 24)
		Me.PeppyDonate.TabIndex = 3
		Me.PeppyDonate.Text = "Peppy6582"
		'
		'HelpLink
		'
		Me.HelpLink.AutoSize = True
		Me.HelpLink.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.HelpLink.LinkColor = System.Drawing.Color.Navy
		Me.HelpLink.Location = New System.Drawing.Point(8, 87)
		Me.HelpLink.Name = "HelpLink"
		Me.HelpLink.Size = New System.Drawing.Size(40, 24)
		Me.HelpLink.TabIndex = 2
		Me.HelpLink.TabStop = True
		Me.HelpLink.Text = "Go!"
		'
		'Label21
		'
		Me.Label21.AutoSize = True
		Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
		Me.Label21.ForeColor = System.Drawing.Color.Navy
		Me.Label21.Location = New System.Drawing.Point(8, 18)
		Me.Label21.Name = "Label21"
		Me.Label21.Size = New System.Drawing.Size(50, 24)
		Me.Label21.TabIndex = 1
		Me.Label21.Text = "Help"
		'
		'HelpList
		'
		Me.HelpList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
		Me.HelpList.FormattingEnabled = True
		Me.HelpList.Items.AddRange(New Object() {"Settings", "Create YouTubeTV Channel/User - Channel", "Create YouTubeTV Playlist - Channel", "Create RSS - Channel"})
		Me.HelpList.Location = New System.Drawing.Point(8, 63)
		Me.HelpList.Name = "HelpList"
		Me.HelpList.Size = New System.Drawing.Size(241, 21)
		Me.HelpList.TabIndex = 0
		'
		'MenuStrip1
		'
		Me.MenuStrip1.Anchor = System.Windows.Forms.AnchorStyles.Top
		Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.None
		Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
		Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
		Me.MenuStrip1.Location = New System.Drawing.Point(1, 0)
		Me.MenuStrip1.Name = "MenuStrip1"
		Me.MenuStrip1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.MenuStrip1.Size = New System.Drawing.Size(45, 24)
		Me.MenuStrip1.TabIndex = 2
		Me.MenuStrip1.Text = "MenuStrip1"
		'
		'FileToolStripMenuItem
		'
		Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AaaToolStripMenuItem, Me.ExitToolStripMenuItem})
		Me.FileToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.TopLeft
		Me.FileToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
		Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
		Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
		Me.FileToolStripMenuItem.Text = "&File"
		Me.FileToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopLeft
		'
		'AaaToolStripMenuItem
		'
		Me.AaaToolStripMenuItem.Name = "AaaToolStripMenuItem"
		Me.AaaToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
		Me.AaaToolStripMenuItem.Text = "Settings"
		'
		'ExitToolStripMenuItem
		'
		Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
		Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
		Me.ExitToolStripMenuItem.Text = "Exit"
		'
		'OpenFileDialog1
		'
		Me.OpenFileDialog1.FileName = "OpenFileDialog1"
		'
		'Status
		'
		Me.Status.Name = "Status"
		Me.Status.Size = New System.Drawing.Size(0, 17)
		'
		'StatusStrip1
		'
		Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
		Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status})
		Me.StatusStrip1.Location = New System.Drawing.Point(0, 693)
		Me.StatusStrip1.Name = "StatusStrip1"
		Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 15, 0)
		Me.StatusStrip1.Size = New System.Drawing.Size(1006, 22)
		Me.StatusStrip1.TabIndex = 1
		Me.StatusStrip1.Text = "StatusStrip1"
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.AutoSize = True
		Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
		Me.ClientSize = New System.Drawing.Size(1006, 715)
		Me.Controls.Add(Me.StatusStrip1)
		Me.Controls.Add(Me.MenuStrip1)
		Me.Controls.Add(Me.TabControl1)
		Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
		Me.MainMenuStrip = Me.MenuStrip1
		Me.Name = "Form1"
		Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
		Me.Text = "PseudoTV Live Manager"
		Me.TabControl1.ResumeLayout(False)
		Me.TabPage1.ResumeLayout(False)
		Me.TabPage1.PerformLayout()
		CType(Me.TVBannerPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.TVPosterPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
		Me.TabPage5.ResumeLayout(False)
		Me.TabPage5.PerformLayout()
		CType(Me.MoviePicture, System.ComponentModel.ISupportInitialize).EndInit()
		Me.TabPage2.ResumeLayout(False)
		Me.TabPage3.ResumeLayout(False)
		Me.TabPage4.ResumeLayout(False)
		Me.TabPage4.PerformLayout()
		Me.TabPage6.ResumeLayout(False)
		Me.TabPage6.PerformLayout()
		CType(Me.LunaDonatePic, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.PeppyDonatePic, System.ComponentModel.ISupportInitialize).EndInit()
		Me.MenuStrip1.ResumeLayout(False)
		Me.MenuStrip1.PerformLayout()
		Me.StatusStrip1.ResumeLayout(False)
		Me.StatusStrip1.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents TVShowList As System.Windows.Forms.ListView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtShowName As System.Windows.Forms.TextBox
    Friend WithEvents txtShowLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SaveTVShow As System.Windows.Forms.Button
    Friend WithEvents TVShowLabel As System.Windows.Forms.Label
    Friend WithEvents TVPosterPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents NetworkList As System.Windows.Forms.ListView
    Friend WithEvents NetworkListSubList As System.Windows.Forms.ListBox
    Friend WithEvents ListTVGenres As System.Windows.Forms.ListBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GenresList As System.Windows.Forms.ListView
    Friend WithEvents GenresListSubList As System.Windows.Forms.ListBox
    Friend WithEvents txtShowNetwork As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TVGuideList As System.Windows.Forms.ListView
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PlayListType As System.Windows.Forms.ComboBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents PlayListLocation As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Option2 As System.Windows.Forms.ComboBox
    Friend WithEvents ChannelName As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ChkPlayInOrder As System.Windows.Forms.CheckBox
    Friend WithEvents ChkPause As System.Windows.Forms.CheckBox
    Friend WithEvents ChkWatched As System.Windows.Forms.CheckBox
    Friend WithEvents ChkUnwatched As System.Windows.Forms.CheckBox
    Friend WithEvents ChkIceLibrary As System.Windows.Forms.CheckBox
    Friend WithEvents ChkExcludeBCT As System.Windows.Forms.CheckBox
    Friend WithEvents ChkPopup As System.Windows.Forms.CheckBox
    Friend WithEvents ChkResume As System.Windows.Forms.CheckBox
    Friend WithEvents ChkRealTime As System.Windows.Forms.CheckBox
    Friend WithEvents ChkRandom As System.Windows.Forms.CheckBox
    Friend WithEvents chkDontPlayChannel As System.Windows.Forms.CheckBox
    Friend WithEvents ChkLogo As System.Windows.Forms.CheckBox
    Friend WithEvents ResetDays As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents InterleavedList As System.Windows.Forms.ListView
    Friend WithEvents NotShows As System.Windows.Forms.ListBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents SchedulingList As System.Windows.Forms.ListView
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TVGuideShowName As System.Windows.Forms.Label
    Friend WithEvents TVGuideSubMenu As System.Windows.Forms.ListView
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents MovieLabel As System.Windows.Forms.Label
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents MovieGenresList As System.Windows.Forms.ListBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents MovieList As System.Windows.Forms.ListView
    Friend WithEvents MoviePicture As System.Windows.Forms.PictureBox
    Friend WithEvents MovieLocation As System.Windows.Forms.TextBox
    Friend WithEvents txtMovieNetwork As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents MovieNetworkListSubList As System.Windows.Forms.ListBox
    Friend WithEvents MovieNetworkList As System.Windows.Forms.ListView
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents MovieIDLabel As System.Windows.Forms.Label
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents GenresListSubListMovies As System.Windows.Forms.ListBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents StrmUrlBox As System.Windows.Forms.TextBox
    Friend WithEvents StrmUrl As System.Windows.Forms.Label
    Friend WithEvents YouTubeType As System.Windows.Forms.ComboBox
    Friend WithEvents ShowTitleBox As System.Windows.Forms.TextBox
    Friend WithEvents ShowTitle As System.Windows.Forms.Label
    Friend WithEvents ShowDescBox As System.Windows.Forms.TextBox
    Friend WithEvents ShowDesc As System.Windows.Forms.Label
    Friend WithEvents MediaLimit As System.Windows.Forms.Label
    Friend WithEvents MediaLimitBox As System.Windows.Forms.ComboBox
    Friend WithEvents SortTypeBox As System.Windows.Forms.ComboBox
    Friend WithEvents SortType As System.Windows.Forms.Label
    Friend WithEvents ListTVPosters As System.Windows.Forms.ListBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ListMoviePosters As System.Windows.Forms.ListBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TVBannerPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ListTVBanners As System.Windows.Forms.ListBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TVPosterSelect As System.Windows.Forms.Button
    Friend WithEvents TVBannerSelect As System.Windows.Forms.Button
    Friend WithEvents MoviePosterSelect As System.Windows.Forms.Button
    Friend WithEvents AddPoster As System.Windows.Forms.Button
    Friend WithEvents AddBanner As System.Windows.Forms.Button
    Friend WithEvents AddMoviePosterButton As System.Windows.Forms.Button
    Friend WithEvents SubChannelType As System.Windows.Forms.ComboBox
    Friend WithEvents GDataDemoLink As System.Windows.Forms.LinkLabel
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents HelpList As System.Windows.Forms.ComboBox
    Friend WithEvents HelpLink As System.Windows.Forms.LinkLabel
    Friend WithEvents PeppyDonatePic As System.Windows.Forms.PictureBox
    Friend WithEvents PeppyDonate As System.Windows.Forms.Label
    Friend WithEvents LunaDonatePic As System.Windows.Forms.PictureBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents PluginType As System.Windows.Forms.ComboBox
    Friend WithEvents AddExcludeBtn As System.Windows.Forms.Button
    Friend WithEvents SaveExcludeBtn As System.Windows.Forms.Button
    Friend WithEvents DelExcludeBtn As System.Windows.Forms.Button
    Friend WithEvents Status As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AaaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
