PseudoTVLive_Manager
====================
This is a new channel manager based off of the original for PseudoTV, with added PseudoTVLive functionality.

Credit for the original:
Messiadbunny
https://github.com/Messiadbunny/PseudoTV_Manager
